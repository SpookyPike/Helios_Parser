"""Optional cold-attenuation backend seam for future XCOM integration.

Phase 4.1 keeps Thomson transmission as the default quick-look baseline. This
module defines the narrow request/response boundary that a future neutral/cold
attenuation backend can implement without forcing a redesign of Derived mode or
the transmission UI.

The intent is to pass already-selected HELIOS snapshot data:

- per-zone material identifiers / labels
- density [g/cm3]
- LOS path length [cm]
- photon energies [keV]

and receive back a transmission curve. The backend remains optional and lazy:
the app must still run without XCOM or any other external attenuation package.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import numpy as np

from helios.runtime import RunContext
from helios.services.derived.models import DerivedRunData
from helios.services.derived.selection import build_analysis_mask, path_length_cm


@dataclass(frozen=True, slots=True)
class ColdAttenuationZone:
    """Single-zone attenuation input for an optional cold backend."""

    zone_index: int
    region_id: int
    material_id: int
    material_label: str | None
    density_g_cm3: float
    path_length_cm: float


@dataclass(frozen=True, slots=True)
class ColdAttenuationRequest:
    """Structured snapshot request that a future XCOM-like backend can consume."""

    snapshot_index: int
    observation_side: str
    line_of_sight_cosine: float
    photon_energies_kev: tuple[float, ...]
    zones: tuple[ColdAttenuationZone, ...]


@dataclass(frozen=True, slots=True)
class ColdAttenuationResult:
    """Backend response for a future cold-baseline transmission service."""

    energies_kev: np.ndarray
    transmission: np.ndarray
    metadata: dict[str, object]


class OptionalColdAttenuationBackend(Protocol):
    """Protocol implemented by optional attenuation backends such as XCOM."""

    def compute_transmission(self, request: ColdAttenuationRequest) -> ColdAttenuationResult:
        """Return transmission for the supplied snapshot request."""


def build_cold_attenuation_request(
    dataset: DerivedRunData,
    context: RunContext,
    *,
    snapshot_index: int,
    parameters,
    geometry,
    photon_energies_kev: tuple[float, ...],
) -> ColdAttenuationRequest:
    """Build the future optional-backend request from the active Derived context.

    This does not call any external backend. It only packages the current HELIOS
    snapshot subset into a stable request object for later attachment to an
    optional XCOM-like service.
    """

    mask, _, _ = build_analysis_mask(
        dataset,
        context,
        snapshot_index=snapshot_index,
        geometry=geometry,
        reuse_viewer_subset=parameters.reuse_viewer_subset,
        derived_region_ids=parameters.derived_region_ids,
        derived_material_ids=parameters.derived_material_ids,
        exclude_entry_region=parameters.exclude_entry_region,
        exclude_low_density=parameters.exclude_low_density,
        min_density_g_cm3=parameters.min_density_g_cm3,
        exclude_opposite_velocity=parameters.exclude_opposite_velocity,
        zone_index_lower=parameters.zone_index_lower,
        zone_index_upper=parameters.zone_index_upper,
        weighting_mode="path_integrated",
    )

    density = np.asarray(dataset.density_g_cm3[int(snapshot_index)], dtype=np.float64)
    path = np.asarray(path_length_cm(dataset, snapshot_index, geometry), dtype=np.float64)

    material_labels_by_id: dict[int, str] = {}
    materials = dataset.materials if isinstance(dataset.materials, dict) else {}
    if "label" in materials and "index" in materials:
        for material_id, label in zip(np.asarray(materials["index"], dtype=np.int32), materials["label"], strict=False):
            material_labels_by_id[int(abs(material_id))] = str(label)

    zones: list[ColdAttenuationZone] = []
    for zone_index in np.flatnonzero(mask):
        material_id = int(abs(dataset.zone_material_index[zone_index]))
        zones.append(
            ColdAttenuationZone(
                zone_index=int(zone_index + 1),
                region_id=int(dataset.zone_region_id[zone_index]),
                material_id=material_id,
                material_label=material_labels_by_id.get(material_id),
                density_g_cm3=float(density[zone_index]),
                path_length_cm=float(path[zone_index]),
            )
        )

    return ColdAttenuationRequest(
        snapshot_index=int(snapshot_index),
        observation_side=str(geometry.observation_side),
        line_of_sight_cosine=float(geometry.line_of_sight_cosine),
        photon_energies_kev=tuple(float(value) for value in photon_energies_kev),
        zones=tuple(zones),
    )
