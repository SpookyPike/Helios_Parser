"""Quick beam-transmission / extinction estimates for HELIOS Derived mode."""

from __future__ import annotations

from typing import TYPE_CHECKING
import math
from typing import Callable

import numpy as np

from helios.runtime import RunContext
from helios.services.constants import THOMSON_CROSS_SECTION_CM2
from helios.services.derived.common import picosecond_drive_warning
from helios.services.derived.models import DerivedPlotBundle, DerivedRunData, DerivedWarning, TransmissionRegionBudget, TransmissionResult
from helios.services.derived.selection import (
    AnalysisStateCache,
    build_analysis_mask,
    cached_time_series_payload,
    cylindrical_path_note,
    path_geometry_summary,
    path_length_cm,
    shared_time_series_selection_state,
)

if TYPE_CHECKING:
    from helios.services.derived.analysis import DerivedAnalysisParameters
    from helios.services.derived.models import AnalysisGeometryMetadata


def _zone_region_dense_index(region_ids: np.ndarray, zone_region_id: np.ndarray) -> np.ndarray:
    dense = np.searchsorted(region_ids, zone_region_id)
    valid = (dense >= 0) & (dense < region_ids.size)
    if np.any(valid):
        valid &= region_ids[dense] == zone_region_id
    if not np.all(valid):
        raise ValueError("Zone-to-region mapping contains region identifiers not present in the region table.")
    return dense.astype(np.int32, copy=False)


def _snapshot_budget(
    dataset: DerivedRunData,
    context: RunContext,
    *,
    snapshot_index: int,
    parameters: "DerivedAnalysisParameters",
    geometry: "AnalysisGeometryMetadata",
    analysis_cache: AnalysisStateCache | None = None,
) -> tuple[dict[str, float], tuple[TransmissionRegionBudget, ...], tuple[DerivedWarning, ...], np.ndarray]:
    warnings: list[DerivedWarning] = []
    mask, _, selection_warnings = build_analysis_mask(
        dataset,
        context,
        snapshot_index=snapshot_index,
        geometry=geometry,
        reuse_viewer_subset=parameters.reuse_viewer_subset,
        derived_region_ids=parameters.derived_region_ids,
        derived_material_ids=parameters.derived_material_ids,
        exclude_entry_region=parameters.exclude_entry_region,
        exclude_low_density=parameters.exclude_low_density,
        min_density_g_cm3=parameters.min_density_g_cm3,
        exclude_opposite_velocity=parameters.exclude_opposite_velocity,
        zone_index_lower=parameters.zone_index_lower,
        zone_index_upper=parameters.zone_index_upper,
        weighting_mode="path_integrated",
        analysis_cache=analysis_cache,
    )
    warnings.extend(selection_warnings)

    density = np.asarray(dataset.density_g_cm3[int(snapshot_index)], dtype=np.float64)
    path = path_length_cm(dataset, snapshot_index, geometry, analysis_cache=analysis_cache)
    electron_density = np.asarray(dataset.electron_density_cm3[int(snapshot_index)], dtype=np.float64)
    active_density = np.where(mask, density, 0.0)
    active_path = np.where(mask, path, 0.0)
    active_electron_density = np.where(mask, electron_density, 0.0)
    areal_density = float(np.sum(active_density * active_path))
    electron_column = float(np.sum(active_electron_density * active_path))
    tau_thomson = float(THOMSON_CROSS_SECTION_CM2 * electron_column)
    transmission = float(math.exp(-tau_thomson)) if math.isfinite(tau_thomson) else float("nan")

    region_ids = np.asarray(dataset.regions["region_index"], dtype=np.int32)
    dense_region_index = _zone_region_dense_index(region_ids, np.asarray(dataset.zone_region_id, dtype=np.int32))
    active_dense = dense_region_index[mask]
    region_areal = np.bincount(
        active_dense,
        weights=(density[mask] * path[mask]),
        minlength=region_ids.size,
    ).astype(np.float64, copy=False)
    region_column = np.bincount(
        active_dense,
        weights=(electron_density[mask] * path[mask]),
        minlength=region_ids.size,
    ).astype(np.float64, copy=False)
    region_zone_count = np.bincount(active_dense, minlength=region_ids.size).astype(np.int32, copy=False)
    active_regions = np.flatnonzero(region_zone_count > 0)
    region_budgets = tuple(
        TransmissionRegionBudget(
            region_id=int(region_ids[region_offset]),
            areal_density_g_cm2=float(region_areal[region_offset]),
            electron_column_cm2=float(region_column[region_offset]),
            thomson_tau=float(THOMSON_CROSS_SECTION_CM2 * region_column[region_offset]),
        )
        for region_offset in active_regions
    )

    if tau_thomson > 3.0:
        warnings.append(DerivedWarning("transmission", "Thomson optical depth is well above unity; the active subset is optically thick to electron scattering.", severity="warning"))
    elif tau_thomson > 1.0:
        warnings.append(DerivedWarning("transmission", "Thomson optical depth exceeds unity; the active subset is optically thick to electron scattering.", severity="caution"))
    if not np.any(mask):
        warnings.append(DerivedWarning("transmission", "No active zones are selected for the transmission estimate.", severity="error"))
    elif float(np.sum(active_path)) <= 0.0:
        warnings.append(DerivedWarning("transmission", "The active geometry produced zero effective path length after filtering.", severity="warning"))
    if geometry.path_length_mode in {"oblique-sec(theta)", "cylindrical-shell-unavailable-fallback-slab"} and abs(float(geometry.line_of_sight_cosine)) < 0.1:
        warnings.append(
            DerivedWarning(
                "transmission",
                "LOS cosine is very small; sec(theta) path-length amplification makes the transmission budget highly geometry-sensitive.",
                severity="warning",
            )
        )

    return (
        {
            "areal_density": areal_density,
            "electron_column": electron_column,
            "tau": tau_thomson,
            "transmission": transmission,
        },
        region_budgets,
        tuple(warnings),
        mask,
    )


def evaluate_transmission(
    dataset: DerivedRunData,
    context: RunContext,
    *,
    snapshot_index: int,
    parameters: "DerivedAnalysisParameters",
    geometry: "AnalysisGeometryMetadata",
    include_time_plots: bool = True,
    analysis_cache: AnalysisStateCache | None = None,
    progress_check: Callable[[], None] | None = None,
) -> TransmissionResult:
    """Compute areal density, electron column, and a Thomson optical-depth budget."""

    warnings: list[DerivedWarning] = [
        DerivedWarning(
            "transmission",
            "Transmission is a Thomson-only quick-look estimate; detailed photoabsorption and warm-dense-matter opacity physics are not included.",
            severity="info",
        )
    ]
    ps_warning = picosecond_drive_warning(
        "transmission",
        dataset,
        "The current transmission quick look is only weakly validated for ps-scale drives and should be treated as an approximate baseline there.",
    )
    if ps_warning is not None:
        warnings.append(ps_warning)
    cylindrical_warning = cylindrical_path_note("transmission", dataset, geometry)
    if cylindrical_warning is not None:
        warnings.append(cylindrical_warning)
    summary, region_budgets, budget_warnings, mask = _snapshot_budget(
        dataset,
        context,
        snapshot_index=snapshot_index,
        parameters=parameters,
        geometry=geometry,
        analysis_cache=analysis_cache,
    )
    warnings.extend(budget_warnings)

    time_plots: tuple[DerivedPlotBundle, ...] = ()
    if include_time_plots:
        time_ns = np.asarray(dataset.time_s, dtype=np.float64) * 1.0e9
        series_cache_key = (
            "transmission.time_series",
            geometry.observation_side,
            round(float(geometry.line_of_sight_angle_deg), 12),
            round(float(geometry.impact_parameter_cm), 12),
            parameters.reuse_viewer_subset,
            tuple(parameters.derived_region_ids or ()),
            tuple(parameters.derived_material_ids or ()),
            bool(parameters.exclude_entry_region),
            bool(parameters.exclude_low_density),
            round(float(parameters.min_density_g_cm3), 12),
            bool(parameters.exclude_opposite_velocity),
            parameters.zone_index_lower,
            parameters.zone_index_upper,
        )

        def _build_time_series() -> dict[str, np.ndarray]:
            n_times = int(dataset.time_s.size)
            areal_series = np.full(n_times, np.nan, dtype=np.float64)
            column_series = np.full(n_times, np.nan, dtype=np.float64)
            tau_series = np.full(n_times, np.nan, dtype=np.float64)
            transmission_series = np.full(n_times, np.nan, dtype=np.float64)
            mask_matrix, _selection_keys = shared_time_series_selection_state(
                dataset,
                context,
                geometry=geometry,
                weighting_mode="path_integrated",
                reuse_viewer_subset=parameters.reuse_viewer_subset,
                derived_region_ids=parameters.derived_region_ids,
                derived_material_ids=parameters.derived_material_ids,
                exclude_entry_region=parameters.exclude_entry_region,
                exclude_low_density=parameters.exclude_low_density,
                min_density_g_cm3=parameters.min_density_g_cm3,
                exclude_opposite_velocity=parameters.exclude_opposite_velocity,
                zone_index_lower=parameters.zone_index_lower,
                zone_index_upper=parameters.zone_index_upper,
                analysis_cache=analysis_cache,
                progress_check=progress_check,
            )
            for time_index in range(n_times):
                if progress_check is not None and (time_index % 8 == 0):
                    progress_check()
                mask = np.asarray(mask_matrix[int(time_index)], dtype=bool)
                density = np.asarray(dataset.density_g_cm3[int(time_index)], dtype=np.float64)
                path = path_length_cm(dataset, time_index, geometry, analysis_cache=analysis_cache)
                electron_density = np.asarray(dataset.electron_density_cm3[int(time_index)], dtype=np.float64)
                active_density = np.where(mask, density, 0.0)
                active_path = np.where(mask, path, 0.0)
                active_electron_density = np.where(mask, electron_density, 0.0)
                point = {
                    "areal_density": float(np.sum(active_density * active_path)),
                    "electron_column": float(np.sum(active_electron_density * active_path)),
                }
                point["tau"] = float(THOMSON_CROSS_SECTION_CM2 * point["electron_column"])
                point["transmission"] = (
                    float(math.exp(point["tau"] * -1.0)) if math.isfinite(float(point["tau"])) else float("nan")
                )
                areal_series[time_index] = float(point["areal_density"])
                column_series[time_index] = float(point["electron_column"])
                tau_series[time_index] = float(point["tau"])
                transmission_series[time_index] = float(point["transmission"])
            return {
                "areal_density": areal_series,
                "electron_column": column_series,
                "tau": tau_series,
                "transmission": transmission_series,
            }

        time_series = cached_time_series_payload(
            series_cache_key,
            analysis_cache=analysis_cache,
            builder=_build_time_series,
        )
        areal_series = np.asarray(time_series["areal_density"], dtype=np.float64)
        column_series = np.asarray(time_series["electron_column"], dtype=np.float64)
        tau_series = np.asarray(time_series["tau"], dtype=np.float64)
        transmission_series = np.asarray(time_series["transmission"], dtype=np.float64)
        time_plots = (
            DerivedPlotBundle(
                key="areal_density",
                title="Areal density vs time",
                x_label="Time [ns]",
                y_label="Areal density [g/cm2]",
                x_values=time_ns,
                y_series=(areal_series,),
                curve_names=("Areal density",),
            ),
            DerivedPlotBundle(
                key="electron_column",
                title="Electron column vs time",
                x_label="Time [ns]",
                y_label="Electron column [1/cm2]",
                x_values=time_ns,
                y_series=(column_series,),
                curve_names=("Electron column",),
            ),
            DerivedPlotBundle(
                key="tau",
                title="Thomson optical depth vs time",
                x_label="Time [ns]",
                y_label="Thomson tau",
                x_values=time_ns,
                y_series=(tau_series,),
                curve_names=("Tau",),
            ),
            DerivedPlotBundle(
                key="transmission",
                title="Thomson transmission vs time",
                x_label="Time [ns]",
                y_label="Transmission",
                x_values=time_ns,
                y_series=(transmission_series,),
                curve_names=("Transmission",),
            ),
        )

    density = np.asarray(dataset.density_g_cm3[int(snapshot_index)], dtype=np.float64)
    electron_density = np.asarray(dataset.electron_density_cm3[int(snapshot_index)], dtype=np.float64)
    path = path_length_cm(dataset, snapshot_index, geometry, analysis_cache=analysis_cache)
    active_density = np.where(mask, density, 0.0)
    active_path = np.where(mask, path, 0.0)
    active_column_density = np.where(mask, electron_density, 0.0)

    reverse = geometry.observation_boundary == "high"
    if reverse:
        active_density = active_density[::-1]
        active_path = active_path[::-1]
        active_column_density = active_column_density[::-1]
    cumulative_depth_um = np.cumsum(active_path) * 1.0e4
    cumulative_areal = np.cumsum(active_density * active_path)
    cumulative_tau = np.cumsum(active_column_density * active_path) * THOMSON_CROSS_SECTION_CM2
    cumulative_transmission = np.exp(-cumulative_tau)

    geometry_summary = (
        f"{geometry.observation_side} side ({geometry.observation_boundary}-index boundary) | "
        f"LOS cos={geometry.line_of_sight_cosine:.3f} | {path_geometry_summary(dataset, geometry)}"
    )
    areal_title = "Cumulative areal density through target"
    tau_title = "Cumulative Thomson tau through target"
    transmission_title = "Cumulative transmission through target"
    depth_label = "Path depth from observation side [um]"
    if str(dataset.metadata.get("geometry", "")).strip().upper() == "CYLINDRICAL":
        areal_title = "Cumulative LOS shell areal density through target"
        tau_title = "Cumulative LOS shell Thomson tau through target"
        transmission_title = "Cumulative LOS shell transmission through target"
        depth_label = "Accumulated LOS shell path [um]"

    return TransmissionResult(
        snapshot_index=int(snapshot_index),
        weighting_mode="path_integrated",
        geometry_summary=geometry_summary,
        areal_density_g_cm2=float(summary["areal_density"]),
        electron_column_cm2=float(summary["electron_column"]),
        thomson_tau=float(summary["tau"]),
        thomson_transmission=float(summary["transmission"]),
        time_plots=time_plots,
        profile_plots=(
            DerivedPlotBundle(
                key="cumulative_areal",
                title=areal_title,
                x_label=depth_label,
                y_label="Areal density [g/cm2]",
                x_values=np.asarray(cumulative_depth_um, dtype=np.float64),
                y_series=(np.asarray(cumulative_areal, dtype=np.float64),),
                curve_names=("Cumulative areal density",),
            ),
            DerivedPlotBundle(
                key="cumulative_tau",
                title=tau_title,
                x_label=depth_label,
                y_label="Thomson tau",
                x_values=np.asarray(cumulative_depth_um, dtype=np.float64),
                y_series=(np.asarray(cumulative_tau, dtype=np.float64),),
                curve_names=("Cumulative tau",),
            ),
            DerivedPlotBundle(
                key="cumulative_transmission",
                title=transmission_title,
                x_label=depth_label,
                y_label="Transmission",
                x_values=np.asarray(cumulative_depth_um, dtype=np.float64),
                y_series=(np.asarray(cumulative_transmission, dtype=np.float64),),
                curve_names=("Cumulative transmission",),
            ),
        ),
        region_budgets=tuple(region_budgets),
        warnings=tuple(warnings),
    )
