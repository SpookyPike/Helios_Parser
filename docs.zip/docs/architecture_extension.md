# HELIOS Analyzer Architecture Note

This note records the current implementation after the coordinate-model,
parser-robustness, derived-stability, and execution/cache hardening passes. It
is the concise engineering reference that sits between the user manual and the
larger collaborator guide.

## Top-level application modes

The shell in [main_app.py](C:/Users/dimab/Documents/Helios_parser/src/helios_app/main_app.py)
registers three modes through `ShellModeSpec`:

- `parser`
- `viewer`
- `derived`

Toolbar and menu actions are shared `QAction` instances. Mode state must stay
single-sourced in the shell.

## Coordinate model

The HELIOS coordinate column is treated as an **edge** coordinate.

Current invariants:

- `edge.shape == n_zones + 1`
- `center.shape == n_zones`
- `edge` must be strictly increasing
- `center[i] = 0.5 * (edge[i] + edge[i + 1])`
- `zone_width[i]` is validated against `edge[i + 1] - edge[i]`

Row `0` is preserved as the inner/left boundary when available. It is not
hard-coded to zero.

The only narrow reconstruction fallback is in
[coordinates.py](C:/Users/dimab/Documents/Helios_parser/src/helios_parser/coordinates.py):
if parsed edges are non-monotonic due to file-precision rounding and the
boundary-plus-width cumulative grid matches within explicit tolerance, that
cumulative grid is used. Material edge/width conflicts are surfaced as
validation issues, not silently corrected.

### Edge vs center usage

Use edges for:

- field-map extents
- moving-mesh corner grids / mesh rendering
- physical region/material boundaries
- inactive masks and boundary overlays
- cylindrical shell geometry factors

Use centers for:

- lineouts
- probes
- zone-centered profiles
- scalar zone readouts
- default runtime coordinate access

## Parser and HDF5 schema

The parser/HDF5 stack now carries explicit coordinate location information.

Key datasets/metadata:

- `/grid/coordinate_center`
- `/grid/coordinate_edge`
- `/grid/dynamic_coordinate_center`
- `/grid/dynamic_coordinate_edge`
- `/grid/zone_width`
- `coordinate_name`
- `coordinate_location`
- `coordinate_dynamic`
- `legacy_coordinate_alias`

Legacy aliases such as `/grid/x` and dynamic `/fields/radius` still load for
compatibility, but internal consumers normalize to explicit edge/center
semantics.

## Runtime API

[reader.py](C:/Users/dimab/Documents/Helios_parser/src/helios_parser/reader.py)
exposes the stable coordinate access surface:

- `get_static_coordinate(location="center" | "edge")`
- `get_dynamic_coordinate(location="center" | "edge")`
- `get_coordinate(..., location="center", prefer_dynamic=True)`

Default behavior is `location="center"` for backward safety in profile code.

Runtime also exposes:

- `get_run_status()`
- `get_visar_support_metadata()`
- `check_visar_readiness()`

Older HDF5 files without explicit run-status metadata load in compatibility
mode and report `state="unknown"` and `source="legacy_hdf5"`.

## Parser robustness and run status

Run/file state is classified as:

- `completed`
- `aborted`
- `truncated`
- `unknown`

If the final snapshot block is structurally incomplete, the parser drops only
that damaged final block and keeps the last fully valid snapshot as the
effective endpoint. The metadata records:

- `dropped_partial_final_block`
- `damaged_final_block_reason`
- `last_valid_snapshot_time_s`
- footer/intended-end-time information

The declared simulation end time may differ from the last fully parseable block
time. That mismatch is surfaced as status metadata or notes, not treated as an
automatic parser failure.

Malformed numeric tokens such as `4.973-174` are handled with staged parsing:

- fast path for clean numeric blocks
- fallback normalization for malformed or mixed blocks

## Viewer geometry semantics

The viewer uses edges where geometry requires edges and centers where reporting
requires centers.

Planar runs are labeled with `x`; cylindrical runs are labeled with `radius` /
`r`.

Specific behavior:

- map extents are edge-based
- moving-mesh geometry is edge-based
- lineouts and probes are center-based
- region/material boundaries use true edges
- cylindrical near-axis handling preserves non-negative inner boundaries

## Derived-analysis semantics

Derived modules use shared geometry/filtering/weighting helpers in
[selection.py](C:/Users/dimab/Documents/Helios_parser/src/helios/services/derived/selection.py).

Current exact local cylindrical correction:

- cylindrical `mass` weighting uses shell geometry from edge coordinates

Current explicit approximation:

- plasmon, transmission, and spectroscopy still use slab-like `sec(theta)` LOS
  path scaling for cylindrical runs; this is warned explicitly and not
  documented as exact cylindrical transport.

## Execution model

[tasks.py](C:/Users/dimab/Documents/Helios_parser/src/helios/tasks.py)
provides asynchronous derived execution using a persistent `QThreadPool`
configuration instead of spawning a new `QThread` per request.

Current guarantees:

- derived work stays off the GUI thread
- cooperative cancellation is used for superseded work
- latest-wins request semantics are enforced
- stale or cancelled results are ignored
- malformed/incomplete result payloads are rejected before UI apply

## Cache model

[cache.py](C:/Users/dimab/Documents/Helios_parser/src/helios/cache.py)
provides bounded cache buckets.

Observed cache stats include:

- `size`
- `capacity`
- `hits`
- `misses`
- `evictions`
- `clears`
- `last_clear_reason`

This is a lightweight introspection surface for performance debugging and
memory-discipline validation, not a full monitoring framework.

## Plotting memory semantics

The field-map and curve hot paths now avoid unnecessary copies where safe.

Rule:

- arrays handed into hot plotting paths may be retained by reference and must
  be treated as immutable after handoff

Copies are still made when required, for example:

- transformed/log display paths
- export isolation
- clone isolation
