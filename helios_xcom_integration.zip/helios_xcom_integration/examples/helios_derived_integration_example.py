from __future__ import annotations

"""Minimal example of how a HELIOS derived-analysis layer could call helios_xcom.

This is intentionally generic: it only assumes you already have per-zone
material labels, densities, and path lengths for the selected snapshot.
"""

from helios_xcom import compute_multizone_transmission, default_client


def evaluate_selected_snapshot_transmission(
    *,
    material_labels: list[str],
    density_g_cm3: list[float],
    path_length_cm: list[float],
    photon_energy_kev: float,
) -> dict[str, object]:
    client = default_client()
    curve = compute_multizone_transmission(
        client,
        material_specs=material_labels,
        density_g_cm3=density_g_cm3,
        path_length_cm=path_length_cm,
        energies_kev=[photon_energy_kev],
    )
    return {
        "photon_energy_kev": curve.energies_kev[0],
        "optical_depth": curve.optical_depth[0],
        "transmission": curve.transmission[0],
        "per_material": [
            {
                "label": item.label,
                "areal_density_g_cm2": item.areal_density_g_cm2,
                "optical_depth": item.optical_depth[0],
            }
            for item in curve.per_material
        ],
    }
