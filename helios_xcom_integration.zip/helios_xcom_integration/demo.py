from __future__ import annotations

import json
from pathlib import Path

from helios_xcom import CompoundSpec, ElementSpec, MixtureSpec, compute_multizone_transmission, default_client


def main() -> None:
    client = default_client()

    fe = client.query(ElementSpec(symbol="Fe"), energies_kev=[6.9, 7.05, 7.11, 7.2, 8.0, 10.0])
    ch = client.query(CompoundSpec("CH"), energies_kev=[8.0, 10.0])
    mix = client.query(MixtureSpec([("Fe", 0.7), ("CH", 0.3)]), energies_kev=[8.0, 10.0])
    slab = client.uniform_slab_transmission(ElementSpec(symbol="Fe"), density_g_cm3=7.874, path_length_cm=1e-4, energies_kev=[8.0, 10.0, 12.0])
    multizone = compute_multizone_transmission(
        client,
        material_specs=["Fe", "Fe", "CH"],
        density_g_cm3=[7.874, 7.874, 1.0],
        path_length_cm=[1e-4, 2e-4, 5e-4],
        energies_kev=[8.0, 10.0, 12.0],
    )

    summary = {
        "fe": fe.to_dict(),
        "ch": ch.to_dict(),
        "mix": mix.to_dict(),
        "uniform_slab": {
            "energies_kev": list(slab.energies_kev),
            "tau": list(slab.optical_depth),
            "transmission": list(slab.transmission),
            "attenuation_mode": slab.attenuation_mode,
        },
        "multizone": {
            "energies_kev": list(multizone.energies_kev),
            "tau": list(multizone.optical_depth),
            "transmission": list(multizone.transmission),
            "per_material": [
                {
                    "label": item.label,
                    "areal_density_g_cm2": item.areal_density_g_cm2,
                    "optical_depth": list(item.optical_depth),
                }
                for item in multizone.per_material
            ],
        },
    }
    out = Path(__file__).resolve().parent / "demo_results.json"
    out.write_text(json.dumps(summary, indent=2, sort_keys=True))
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
