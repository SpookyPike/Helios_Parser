from __future__ import annotations

import unittest

from helios_xcom.backend import XCOMBackend


class BackendTests(unittest.TestCase):
    def test_query_fe_real_backend(self) -> None:
        backend = XCOMBackend()
        result = backend.query({"kind": "element_symbol", "symbol": "Fe", "name": "Iron"}, energies_mev=[0.008, 0.01], include_standard_grid=False)
        self.assertEqual(len(result["energy_kev"]), 2)
        self.assertGreater(result["mu_rho_cm2_g"]["total_with_coherent"][0], 0.0)
        self.assertIn("backend_fingerprint", result)
