from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from helios_xcom.cache import SQLiteQueryCache
from helios_xcom.client import XCOMClient
from helios_xcom.backend import XCOMBackend
from helios_xcom.models import CompoundSpec, ElementSpec, MixtureSpec


class ClientTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.cache = SQLiteQueryCache(Path(self.tmpdir.name) / "cache.sqlite3")
        self.client = XCOMClient(backend=XCOMBackend(), cache=self.cache)

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_cache_hit_on_second_call(self) -> None:
        spec = ElementSpec(symbol="Fe")
        energies = [8.0, 10.0]
        first = self.client.query(spec, energies_kev=energies)
        second = self.client.query(spec, energies_kev=energies)
        self.assertFalse(first.cache_hit)
        self.assertTrue(second.cache_hit)
        self.assertEqual(first.energy_kev, second.energy_kev)

    def test_compound_query(self) -> None:
        result = self.client.query(CompoundSpec("CH"), energies_kev=[8.0, 10.0])
        self.assertEqual(len(result.energy_kev), 2)
        self.assertGreater(result.total_with_coherent_cm2_g[0], 0.0)

    def test_mixture_query(self) -> None:
        result = self.client.query(MixtureSpec([("Fe", 0.7), ("CH", 0.3)]), energies_kev=[8.0, 10.0])
        self.assertEqual(len(result.energy_kev), 2)
        self.assertGreater(result.total_with_coherent_cm2_g[1], 0.0)

    def test_uniform_slab_transmission(self) -> None:
        curve = self.client.uniform_slab_transmission(ElementSpec(symbol="Fe"), density_g_cm3=7.874, path_length_cm=1e-4, energies_kev=[8.0, 10.0])
        self.assertEqual(len(curve.transmission), 2)
        self.assertTrue(all(0.0 < value <= 1.0 for value in curve.transmission))
