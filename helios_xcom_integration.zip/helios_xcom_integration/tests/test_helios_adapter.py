from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from helios_xcom.backend import XCOMBackend
from helios_xcom.cache import SQLiteQueryCache
from helios_xcom.client import XCOMClient
from helios_xcom.helios_adapter import compute_snapshot_transmission, estimate_path_lengths_from_zone_width, snapshot_input_from_arrays


class HeliosAdapterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.client = XCOMClient(backend=XCOMBackend(), cache=SQLiteQueryCache(Path(self.tmpdir.name) / "cache.sqlite3"))

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_path_length_projection(self) -> None:
        projected = estimate_path_lengths_from_zone_width([1.0, 2.0], cosine_incidence=0.5)
        self.assertEqual(projected, (2.0, 4.0))

    def test_snapshot_transmission(self) -> None:
        snapshot = snapshot_input_from_arrays(material_specs=["Fe", "CH"], density_g_cm3=[7.874, 1.0], path_length_cm=[1e-4, 5e-4])
        result = compute_snapshot_transmission(self.client, snapshot, energies_kev=[8.0, 10.0], snapshot_index=3)
        self.assertEqual(result.snapshot_index, 3)
        self.assertEqual(len(result.curve.transmission), 2)
