from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from helios_xcom.attenuation import compute_multizone_transmission
from helios_xcom.backend import XCOMBackend
from helios_xcom.cache import SQLiteQueryCache
from helios_xcom.client import XCOMClient


class AttenuationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.client = XCOMClient(backend=XCOMBackend(), cache=SQLiteQueryCache(Path(self.tmpdir.name) / "cache.sqlite3"))

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_multizone_transmission(self) -> None:
        curve = compute_multizone_transmission(
            self.client,
            material_specs=["Fe", "CH"],
            density_g_cm3=[7.874, 1.0],
            path_length_cm=[1e-4, 5e-4],
            energies_kev=[8.0, 10.0],
        )
        self.assertEqual(len(curve.optical_depth), 2)
        self.assertEqual(len(curve.per_material), 2)
        self.assertTrue(all(0.0 < value <= 1.0 for value in curve.transmission))
