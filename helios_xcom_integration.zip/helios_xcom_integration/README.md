# HELIOS XCOM Integration

Integration-ready wrapper around the legacy NIST XCOM 3.1 engine.

## What this package provides

- native XCOM backend build and execution;
- thin Python adapter with typed material specifications;
- persistent SQLite query cache;
- Beer-Lambert attenuation helpers;
- HELIOS-compatible array-level attenuation helpers;
- test suite that runs against the real vendor XCOM source.

## Scope

This package treats XCOM as a **cold / neutral attenuation backend**.
It is appropriate for baseline hard-X-ray attenuation and extinction estimates in solids, compounds, and mixtures.

It does **not** model plasma-state opacity in warm dense / ionized matter.

## Main entry points

```python
from helios_xcom import (
    ElementSpec,
    CompoundSpec,
    MixtureSpec,
    default_client,
)

client = default_client()
result = client.query(ElementSpec(symbol="Fe"), energies_kev=[8.0, 10.0, 12.0])
curve = client.uniform_slab_transmission(
    ElementSpec(symbol="Fe"),
    density_g_cm3=7.874,
    path_length_cm=1.0e-4,
    energies_kev=[8.0, 10.0, 12.0],
)
```

## HELIOS-oriented helper

```python
from helios_xcom import compute_multizone_transmission

curve = compute_multizone_transmission(
    client,
    material_specs=["Fe", "Fe", "CH"],
    density_g_cm3=[7.8, 7.8, 1.0],
    path_length_cm=[1e-4, 2e-4, 5e-4],
    energies_kev=[8.0, 10.0],
)
```

## Runtime layout

The package stores writable runtime artifacts in a user data root:

- compiled binary
- SQLite cache
- optional logs

This keeps the package itself read-only and deployment-friendly.
