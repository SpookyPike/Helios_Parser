# Integration notes for HELIOS viewer / derived services

## Recommended insertion points

1. Keep `helios_xcom` as a self-contained package.
2. In a future derived-analysis module, create one long-lived `XCOMClient` instance.
3. Reuse that client for all attenuation/transmission requests so the SQLite cache stays hot.
4. Build per-zone path lengths from the active line of sight and moving-mesh geometry.
5. For each selected snapshot, pass:
   - per-zone material labels or formulas,
   - density in g/cm^3,
   - effective path length in cm,
   - photon energy in keV.
6. Use `compute_multizone_transmission(...)` to obtain total optical depth and transmission.

## Practical first integration target

A good first product feature is a single-snapshot transmission calculator:

- user chooses photon energy,
- viewer uses selected zones / current subset,
- viewer computes line-of-sight path lengths,
- attenuation service returns total transmission and per-material budget.

## Deliberate limitation

This package intentionally treats XCOM as a cold / neutral attenuation backend.
For warm dense or strongly ionized plasma, the viewer should label the result as a baseline approximation.
