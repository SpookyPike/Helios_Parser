These artifacts were generated inside the current sandbox while validating the package.

Included:
- demo_results.json      -> output of demo.py
- TEST_REPORT.txt        -> unittest report
- xcom_queries.sqlite3   -> SQLite cache populated by the demo/test run

Notes:
- the cache database is portable;
- the compiled binary used during validation is NOT bundled as the default runtime path should rebuild it on the target machine if needed.
