from __future__ import annotations

import os
import sys
from pathlib import Path


APP_NAME = "helios_xcom"


def user_data_root() -> Path:
    if sys.platform.startswith("win"):
        base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Caches"
    else:
        base = Path(os.environ.get("XDG_CACHE_HOME") or (Path.home() / ".cache"))
    root = base / APP_NAME
    root.mkdir(parents=True, exist_ok=True)
    return root


def runtime_bin_dir() -> Path:
    path = user_data_root() / "bin"
    path.mkdir(parents=True, exist_ok=True)
    return path


def runtime_cache_dir() -> Path:
    path = user_data_root() / "cache"
    path.mkdir(parents=True, exist_ok=True)
    return path
