from __future__ import annotations

import os
import re
import subprocess
import time
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from .build import ensure_binary, source_digest
from .exceptions import XCOMParseError, XCOMQueryError
from .vendor import vendor_root

_FLOAT_RE = re.compile(r"[-+]?\d*\.\d+(?:[Ee][-+]?\d+)?|[-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?")


@dataclass(slots=True)
class XCOMBackend:
    timeout_s: float = 30.0

    @property
    def backend_fingerprint(self) -> str:
        return f"xcom-cli:{source_digest()}"

    def query(
        self,
        material_payload: Mapping[str, Any],
        *,
        energies_mev: Sequence[float] | None,
        include_standard_grid: bool,
        output_quantities: int = 3,
    ) -> dict[str, Any]:
        binary = ensure_binary()
        unique = f"{os.getpid()}_{int(time.time() * 1e6) % 100000000:08d}"
        output_name = f"XOUT_{unique}.TXT"
        output_path = vendor_root() / output_name
        stdin_payload = self._build_stdin(
            material_payload,
            energies_mev=energies_mev,
            include_standard_grid=include_standard_grid,
            output_quantities=output_quantities,
            output_name=output_name,
        )
        started = time.perf_counter()
        proc = subprocess.run(
            [str(binary)],
            cwd=vendor_root(),
            input=stdin_payload,
            text=True,
            capture_output=True,
            timeout=self.timeout_s,
        )
        runtime_s = time.perf_counter() - started
        if proc.returncode != 0:
            raise XCOMQueryError(
                f"XCOM query failed with return code {proc.returncode}\n"
                f"STDOUT:\n{proc.stdout}\n"
                f"STDERR:\n{proc.stderr}"
            )
        if not output_path.exists():
            raise XCOMQueryError(
                f"XCOM completed but did not create the output table {output_name}\n"
                f"STDOUT:\n{proc.stdout}\n"
                f"STDERR:\n{proc.stderr}"
            )
        try:
            parsed = self._parse_output(output_path.read_text())
        finally:
            output_path.unlink(missing_ok=True)
        parsed["runtime_s"] = runtime_s
        parsed["backend_fingerprint"] = self.backend_fingerprint
        return parsed

    @staticmethod
    def _build_stdin(
        material_payload: Mapping[str, Any],
        *,
        energies_mev: Sequence[float] | None,
        include_standard_grid: bool,
        output_quantities: int,
        output_name: str,
    ) -> str:
        lines: list[str] = []
        lines.append(str(material_payload.get("name") or "XCOM query"))
        kind = material_payload["kind"]
        prompt_output_choice = False
        if kind == "element_z":
            lines.extend(["1", str(int(material_payload["atomic_number"]))])
            prompt_output_choice = True
        elif kind == "element_symbol":
            lines.extend(["2", str(material_payload["symbol"])])
            prompt_output_choice = True
        elif kind == "compound":
            lines.extend(["3", str(material_payload["formula"])])
        elif kind == "mixture":
            components = material_payload["components"]
            lines.extend(["4", str(len(components))])
            for item in components:
                lines.append(str(item["component"]))
                lines.append(repr(float(item["weight_fraction"])))
            lines.append("1")
        else:
            raise ValueError(f"Unsupported material kind: {kind}")

        if prompt_output_choice:
            lines.append(str(int(output_quantities)))

        if energies_mev:
            lines.append("2" if include_standard_grid else "3")
            lines.extend(["1", str(len(energies_mev))])
            lines.extend(repr(float(value)) for value in energies_mev)
            lines.append("N")
        else:
            lines.append("1")

        lines.append(output_name)
        lines.append("1")
        return "\n".join(lines) + "\n"

    @staticmethod
    def _parse_output(text: str) -> dict[str, Any]:
        lines = text.splitlines()
        if not lines:
            raise XCOMParseError("Empty XCOM output table")
        title = lines[0].strip()
        constituents: list[str] = []
        rows: list[list[float]] = []
        in_constituents = False
        for raw_line in lines:
            stripped = raw_line.strip()
            if "Constituents" in stripped:
                in_constituents = True
                continue
            if in_constituents:
                if not stripped:
                    in_constituents = False
                elif ":" in stripped:
                    constituents.append(stripped)
                continue
            if not stripped:
                continue
            if stripped.startswith("PHOTON") or stripped.startswith("ENERGY") or stripped.startswith("("):
                continue
            if stripped[0].isdigit() or stripped[0] in "+-.":
                values = [float(token) for token in _FLOAT_RE.findall(stripped)]
                if len(values) == 8:
                    rows.append(values)
        if not rows:
            raise XCOMParseError("Failed to parse numeric rows from XCOM output")
        energy_mev = [row[0] for row in rows]
        coherent = [row[1] for row in rows]
        incoherent = [row[2] for row in rows]
        photoelectric = [row[3] for row in rows]
        pair_nuclear = [row[4] for row in rows]
        pair_electron = [row[5] for row in rows]
        total_with_coherent = [row[6] for row in rows]
        total_without_coherent = [row[7] for row in rows]
        return {
            "title": title,
            "constituents": constituents,
            "energy_mev": energy_mev,
            "energy_kev": [value * 1.0e3 for value in energy_mev],
            "mu_rho_cm2_g": {
                "coherent": coherent,
                "incoherent": incoherent,
                "photoelectric": photoelectric,
                "pair_nuclear": pair_nuclear,
                "pair_electron": pair_electron,
                "total_with_coherent": total_with_coherent,
                "total_without_coherent": total_without_coherent,
            },
        }
