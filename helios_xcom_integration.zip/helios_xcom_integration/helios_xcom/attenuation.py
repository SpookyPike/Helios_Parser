from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Sequence

from .models import MaterialSpec, QueryResult, TransmissionResult, canonicalize_material_spec


@dataclass(frozen=True, slots=True)
class MaterialBudget:
    label: str
    areal_density_g_cm2: float
    optical_depth: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class AttenuationCurve:
    energies_kev: tuple[float, ...]
    optical_depth: tuple[float, ...]
    transmission: tuple[float, ...]
    attenuation_mode: str
    per_material: tuple[MaterialBudget, ...] = ()


def _select_mu_rho(result: QueryResult, *, use_total_without_coherent: bool) -> tuple[float, ...]:
    return result.total_without_coherent_cm2_g if use_total_without_coherent else result.total_with_coherent_cm2_g


def compute_uniform_slab_transmission(result: QueryResult, *, density_g_cm3: float, path_length_cm: float, use_total_without_coherent: bool = False) -> TransmissionResult:
    if density_g_cm3 < 0.0 or path_length_cm < 0.0:
        raise ValueError("density_g_cm3 and path_length_cm must be non-negative")
    mu_rho = _select_mu_rho(result, use_total_without_coherent=use_total_without_coherent)
    tau = tuple(float(value) * density_g_cm3 * path_length_cm for value in mu_rho)
    transmission = tuple(math.exp(-value) for value in tau)
    return TransmissionResult(
        energies_kev=result.energy_kev,
        mu_rho_cm2_g=mu_rho,
        density_g_cm3=float(density_g_cm3),
        path_length_cm=float(path_length_cm),
        optical_depth=tau,
        transmission=transmission,
        attenuation_mode="total_without_coherent" if use_total_without_coherent else "total_with_coherent",
        cache_hit=bool(result.cache_hit),
    )


def compute_multizone_transmission(client: "XCOMClient", *, material_specs: Sequence[MaterialSpec], density_g_cm3: Sequence[float], path_length_cm: Sequence[float], energies_kev: Sequence[float], use_total_without_coherent: bool = False) -> AttenuationCurve:
    from .client import XCOMClient

    if not isinstance(client, XCOMClient):
        raise TypeError("client must be an XCOMClient instance")
    if not (len(material_specs) == len(density_g_cm3) == len(path_length_cm)):
        raise ValueError("material_specs, density_g_cm3, and path_length_cm must have the same length")
    energies_kev = tuple(float(value) for value in energies_kev)
    if not energies_kev:
        raise ValueError("energies_kev must be non-empty")
    total_tau = [0.0 for _ in energies_kev]
    budgets: list[MaterialBudget] = []
    for index, (spec, density, path) in enumerate(zip(material_specs, density_g_cm3, path_length_cm)):
        density = float(density)
        path = float(path)
        if density < 0.0 or path < 0.0:
            raise ValueError("density and path_length must be non-negative")
        if density == 0.0 or path == 0.0:
            continue
        query = client.query(canonicalize_material_spec(spec), energies_kev=energies_kev)
        mu_rho = _select_mu_rho(query, use_total_without_coherent=use_total_without_coherent)
        zone_tau = tuple(float(value) * density * path for value in mu_rho)
        for i, value in enumerate(zone_tau):
            total_tau[i] += value
        budgets.append(
            MaterialBudget(
                label=query.material_payload.get("name") or query.title or f"zone_{index}",
                areal_density_g_cm2=density * path,
                optical_depth=zone_tau,
            )
        )
    transmission = tuple(math.exp(-value) for value in total_tau)
    return AttenuationCurve(
        energies_kev=energies_kev,
        optical_depth=tuple(total_tau),
        transmission=transmission,
        attenuation_mode="total_without_coherent" if use_total_without_coherent else "total_with_coherent",
        per_material=tuple(budgets),
    )
