from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .runtime_paths import runtime_cache_dir


def stable_query_key(payload: Mapping[str, Any]) -> str:
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


@dataclass(slots=True)
class SQLiteQueryCache:
    path: Path

    def __post_init__(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    @classmethod
    def default(cls) -> "SQLiteQueryCache":
        return cls(runtime_cache_dir() / "xcom_queries.sqlite3")

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def _initialize(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS xcom_cache (
                    query_key TEXT PRIMARY KEY,
                    payload_json TEXT NOT NULL,
                    result_json TEXT NOT NULL,
                    backend_fingerprint TEXT NOT NULL,
                    created_at REAL NOT NULL
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_xcom_cache_backend ON xcom_cache(backend_fingerprint)")

    def get(self, payload: Mapping[str, Any], *, backend_fingerprint: str) -> dict[str, Any] | None:
        query_key = stable_query_key(payload)
        with self._connect() as conn:
            row = conn.execute(
                "SELECT result_json FROM xcom_cache WHERE query_key = ? AND backend_fingerprint = ?",
                (query_key, backend_fingerprint),
            ).fetchone()
        if row is None:
            return None
        return json.loads(row[0])

    def put(self, payload: Mapping[str, Any], result: Mapping[str, Any], *, backend_fingerprint: str) -> None:
        query_key = stable_query_key(payload)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO xcom_cache(query_key, payload_json, result_json, backend_fingerprint, created_at)
                VALUES(?, ?, ?, ?, ?)
                ON CONFLICT(query_key) DO UPDATE SET
                    payload_json=excluded.payload_json,
                    result_json=excluded.result_json,
                    backend_fingerprint=excluded.backend_fingerprint,
                    created_at=excluded.created_at
                """,
                (
                    query_key,
                    json.dumps(payload, sort_keys=True, separators=(",", ":")),
                    json.dumps(result, sort_keys=True, separators=(",", ":")),
                    backend_fingerprint,
                    time.time(),
                ),
            )

    def clear(self) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM xcom_cache")
