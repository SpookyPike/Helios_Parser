from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from .attenuation import AttenuationCurve, compute_multizone_transmission
from .client import XCOMClient
from .models import MaterialSpec


@dataclass(frozen=True, slots=True)
class SnapshotTransmissionInput:
    material_specs: tuple[MaterialSpec, ...]
    density_g_cm3: tuple[float, ...]
    path_length_cm: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class SnapshotTransmissionResult:
    snapshot_index: int
    curve: AttenuationCurve


def snapshot_input_from_arrays(*, material_specs: Sequence[MaterialSpec], density_g_cm3: Sequence[float], path_length_cm: Sequence[float]) -> SnapshotTransmissionInput:
    if not (len(material_specs) == len(density_g_cm3) == len(path_length_cm)):
        raise ValueError("material_specs, density_g_cm3, and path_length_cm must have the same length")
    return SnapshotTransmissionInput(
        material_specs=tuple(material_specs),
        density_g_cm3=tuple(float(value) for value in density_g_cm3),
        path_length_cm=tuple(float(value) for value in path_length_cm),
    )


def compute_snapshot_transmission(client: XCOMClient, snapshot: SnapshotTransmissionInput, *, energies_kev: Sequence[float], snapshot_index: int = 0) -> SnapshotTransmissionResult:
    curve = compute_multizone_transmission(
        client,
        material_specs=snapshot.material_specs,
        density_g_cm3=snapshot.density_g_cm3,
        path_length_cm=snapshot.path_length_cm,
        energies_kev=energies_kev,
    )
    return SnapshotTransmissionResult(snapshot_index=int(snapshot_index), curve=curve)


def estimate_path_lengths_from_zone_width(zone_width_cm: Sequence[float], *, cosine_incidence: float = 1.0) -> tuple[float, ...]:
    cosine = float(cosine_incidence)
    if cosine <= 0.0:
        raise ValueError("cosine_incidence must be positive")
    return tuple(float(width) / cosine for width in zone_width_cm)
