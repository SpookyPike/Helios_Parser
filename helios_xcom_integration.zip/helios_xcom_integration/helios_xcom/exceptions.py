class XCOMError(RuntimeError):
    """Base exception for HELIOS XCOM integration."""


class XCOMBuildError(XCOMError):
    """Raised when the vendor XCOM backend cannot be built."""


class XCOMQueryError(XCOMError):
    """Raised when a runtime XCOM query fails."""


class XCOMParseError(XCOMError):
    """Raised when an XCOM output table cannot be parsed."""
