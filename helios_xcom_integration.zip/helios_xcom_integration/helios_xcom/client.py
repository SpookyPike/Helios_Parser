from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Sequence

from .attenuation import compute_uniform_slab_transmission
from .backend import XCOMBackend
from .cache import SQLiteQueryCache
from .models import MaterialSpec, QueryResult, TransmissionResult, canonicalize_material_spec


@dataclass(slots=True)
class XCOMClient:
    backend: XCOMBackend
    cache: SQLiteQueryCache | None = None

    def query(
        self,
        spec: MaterialSpec,
        *,
        energies_kev: Sequence[float] | None = None,
        energies_mev: Sequence[float] | None = None,
        include_standard_grid: bool = False,
        refresh_cache: bool = False,
    ) -> QueryResult:
        if energies_kev is not None and energies_mev is not None:
            raise ValueError("Specify only one of energies_kev or energies_mev")
        material = canonicalize_material_spec(spec)
        if energies_kev is not None:
            energies_mev = [float(value) / 1.0e3 for value in energies_kev]
        payload = {
            "material": material.to_payload(),
            "energies_mev": [float(value) for value in energies_mev] if energies_mev is not None else None,
            "include_standard_grid": bool(include_standard_grid),
            "output_quantities": 3,
        }
        if self.cache is not None and not refresh_cache:
            cached = self.cache.get(payload, backend_fingerprint=self.backend.backend_fingerprint)
            if cached is not None:
                result = QueryResult.from_dict(cached)
                return replace(result, cache_hit=True)
        raw = self.backend.query(
            payload["material"],
            energies_mev=payload["energies_mev"],
            include_standard_grid=payload["include_standard_grid"],
            output_quantities=payload["output_quantities"],
        )
        result = QueryResult(
            title=str(raw["title"]),
            constituents=tuple(str(x) for x in raw.get("constituents", ())),
            energy_mev=tuple(float(x) for x in raw["energy_mev"]),
            energy_kev=tuple(float(x) for x in raw["energy_kev"]),
            coherent_cm2_g=tuple(float(x) for x in raw["mu_rho_cm2_g"]["coherent"]),
            incoherent_cm2_g=tuple(float(x) for x in raw["mu_rho_cm2_g"]["incoherent"]),
            photoelectric_cm2_g=tuple(float(x) for x in raw["mu_rho_cm2_g"]["photoelectric"]),
            pair_nuclear_cm2_g=tuple(float(x) for x in raw["mu_rho_cm2_g"]["pair_nuclear"]),
            pair_electron_cm2_g=tuple(float(x) for x in raw["mu_rho_cm2_g"]["pair_electron"]),
            total_with_coherent_cm2_g=tuple(float(x) for x in raw["mu_rho_cm2_g"]["total_with_coherent"]),
            total_without_coherent_cm2_g=tuple(float(x) for x in raw["mu_rho_cm2_g"]["total_without_coherent"]),
            material_payload=payload["material"],
            include_standard_grid=bool(payload["include_standard_grid"]),
            runtime_s=float(raw["runtime_s"]),
            backend_fingerprint=str(raw["backend_fingerprint"]),
            cache_hit=False,
        )
        if self.cache is not None:
            self.cache.put(payload, result.to_dict(), backend_fingerprint=self.backend.backend_fingerprint)
        return result

    def uniform_slab_transmission(
        self,
        spec: MaterialSpec,
        *,
        density_g_cm3: float,
        path_length_cm: float,
        energies_kev: Sequence[float],
        use_total_without_coherent: bool = False,
    ) -> TransmissionResult:
        result = self.query(spec, energies_kev=energies_kev)
        return compute_uniform_slab_transmission(
            result,
            density_g_cm3=density_g_cm3,
            path_length_cm=path_length_cm,
            use_total_without_coherent=use_total_without_coherent,
        )

    def prewarm(self, queries: Sequence[tuple[MaterialSpec, Sequence[float]]]) -> None:
        for spec, energies in queries:
            self.query(spec, energies_kev=energies)


def default_client() -> XCOMClient:
    return XCOMClient(backend=XCOMBackend(), cache=SQLiteQueryCache.default())
