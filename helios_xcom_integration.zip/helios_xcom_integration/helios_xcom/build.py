from __future__ import annotations

import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

from .exceptions import XCOMBuildError
from .runtime_paths import runtime_bin_dir
from .vendor import vendor_root, vendor_source_file


def source_digest() -> str:
    source = vendor_source_file().read_bytes()
    return hashlib.sha256(source).hexdigest()[:16]


def binary_path() -> Path:
    suffix = ".exe" if sys.platform.startswith("win") else ""
    return runtime_bin_dir() / f"xcom_{source_digest()}{suffix}"


def ensure_binary(force_rebuild: bool = False) -> Path:
    target = binary_path()
    if target.exists() and not force_rebuild:
        return target
    compiler = shutil.which("gfortran")
    if compiler is None:
        raise XCOMBuildError("gfortran is required to build the vendor XCOM backend but was not found")
    cmd = [compiler, "-O2", "-std=legacy", "-fallow-argument-mismatch", str(vendor_source_file()), "-o", str(target)]
    proc = subprocess.run(cmd, cwd=vendor_root(), capture_output=True, text=True)
    if proc.returncode != 0:
        raise XCOMBuildError(
            "Failed to build XCOM backend\n"
            f"Command: {' '.join(cmd)}\n"
            f"STDOUT:\n{proc.stdout}\n"
            f"STDERR:\n{proc.stderr}"
        )
    return target
