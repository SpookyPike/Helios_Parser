from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class ElementSpec:
    symbol: str | None = None
    atomic_number: int | None = None
    name: str | None = None

    def to_payload(self) -> dict[str, Any]:
        if self.symbol is None and self.atomic_number is None:
            raise ValueError("ElementSpec requires either symbol or atomic_number")
        if self.atomic_number is not None:
            return {
                "kind": "element_z",
                "atomic_number": int(self.atomic_number),
                "name": self.name or f"Z={int(self.atomic_number)}",
            }
        return {
            "kind": "element_symbol",
            "symbol": str(self.symbol),
            "name": self.name or str(self.symbol),
        }


@dataclass(frozen=True, slots=True)
class CompoundSpec:
    formula: str
    name: str | None = None

    def to_payload(self) -> dict[str, Any]:
        formula = str(self.formula).strip()
        if not formula:
            raise ValueError("CompoundSpec requires a non-empty formula")
        return {
            "kind": "compound",
            "formula": formula,
            "name": self.name or formula,
        }


@dataclass(frozen=True, slots=True)
class MixtureSpec:
    components: tuple[tuple[str, float], ...]
    name: str | None = None

    def __init__(self, components: Sequence[tuple[str, float]], name: str | None = None) -> None:
        normalized = tuple((str(component).strip(), float(weight)) for component, weight in components)
        if not normalized:
            raise ValueError("MixtureSpec requires at least one component")
        if any(not component for component, _ in normalized):
            raise ValueError("MixtureSpec components must have non-empty names")
        if sum(weight for _, weight in normalized) <= 0.0:
            raise ValueError("MixtureSpec weights must sum to a positive value")
        object.__setattr__(self, "components", normalized)
        object.__setattr__(self, "name", name)

    def to_payload(self) -> dict[str, Any]:
        total = sum(weight for _, weight in self.components)
        normalized = tuple(sorted((component, weight / total) for component, weight in self.components))
        return {
            "kind": "mixture",
            "components": [
                {"component": component, "weight_fraction": weight_fraction}
                for component, weight_fraction in normalized
            ],
            "name": self.name or " + ".join(f"{component}:{weight_fraction:.6g}" for component, weight_fraction in normalized),
        }


MaterialSpec = ElementSpec | CompoundSpec | MixtureSpec | str


@dataclass(frozen=True, slots=True)
class QueryResult:
    title: str
    constituents: tuple[str, ...]
    energy_mev: tuple[float, ...]
    energy_kev: tuple[float, ...]
    coherent_cm2_g: tuple[float, ...]
    incoherent_cm2_g: tuple[float, ...]
    photoelectric_cm2_g: tuple[float, ...]
    pair_nuclear_cm2_g: tuple[float, ...]
    pair_electron_cm2_g: tuple[float, ...]
    total_with_coherent_cm2_g: tuple[float, ...]
    total_without_coherent_cm2_g: tuple[float, ...]
    material_payload: Mapping[str, Any]
    include_standard_grid: bool
    runtime_s: float
    backend_fingerprint: str
    cache_hit: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "constituents": list(self.constituents),
            "energy_mev": list(self.energy_mev),
            "energy_kev": list(self.energy_kev),
            "mu_rho_cm2_g": {
                "coherent": list(self.coherent_cm2_g),
                "incoherent": list(self.incoherent_cm2_g),
                "photoelectric": list(self.photoelectric_cm2_g),
                "pair_nuclear": list(self.pair_nuclear_cm2_g),
                "pair_electron": list(self.pair_electron_cm2_g),
                "total_with_coherent": list(self.total_with_coherent_cm2_g),
                "total_without_coherent": list(self.total_without_coherent_cm2_g),
            },
            "material": dict(self.material_payload),
            "include_standard_grid": bool(self.include_standard_grid),
            "runtime_s": float(self.runtime_s),
            "backend_fingerprint": self.backend_fingerprint,
            "cache_hit": bool(self.cache_hit),
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "QueryResult":
        mu = payload["mu_rho_cm2_g"]
        return cls(
            title=str(payload["title"]),
            constituents=tuple(str(x) for x in payload.get("constituents", ())),
            energy_mev=tuple(float(x) for x in payload["energy_mev"]),
            energy_kev=tuple(float(x) for x in payload["energy_kev"]),
            coherent_cm2_g=tuple(float(x) for x in mu["coherent"]),
            incoherent_cm2_g=tuple(float(x) for x in mu["incoherent"]),
            photoelectric_cm2_g=tuple(float(x) for x in mu["photoelectric"]),
            pair_nuclear_cm2_g=tuple(float(x) for x in mu["pair_nuclear"]),
            pair_electron_cm2_g=tuple(float(x) for x in mu["pair_electron"]),
            total_with_coherent_cm2_g=tuple(float(x) for x in mu["total_with_coherent"]),
            total_without_coherent_cm2_g=tuple(float(x) for x in mu["total_without_coherent"]),
            material_payload=dict(payload["material"]),
            include_standard_grid=bool(payload.get("include_standard_grid", False)),
            runtime_s=float(payload.get("runtime_s", 0.0)),
            backend_fingerprint=str(payload.get("backend_fingerprint", "")),
            cache_hit=bool(payload.get("cache_hit", False)),
        )


@dataclass(frozen=True, slots=True)
class TransmissionResult:
    energies_kev: tuple[float, ...]
    mu_rho_cm2_g: tuple[float, ...]
    density_g_cm3: float
    path_length_cm: float
    optical_depth: tuple[float, ...]
    transmission: tuple[float, ...]
    attenuation_mode: str
    cache_hit: bool


def canonicalize_material_spec(spec: MaterialSpec) -> ElementSpec | CompoundSpec | MixtureSpec:
    if isinstance(spec, (ElementSpec, CompoundSpec, MixtureSpec)):
        return spec
    text = str(spec).strip()
    if not text:
        raise ValueError("Material specification string must be non-empty")
    # Treat a pure alphabetic 1-2 character token as an element symbol; everything else as a compound formula.
    if text.isalpha() and 1 <= len(text) <= 2:
        return ElementSpec(symbol=text)
    return CompoundSpec(text)
