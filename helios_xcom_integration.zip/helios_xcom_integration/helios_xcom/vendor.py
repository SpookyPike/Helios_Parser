from __future__ import annotations

from pathlib import Path


def vendor_root() -> Path:
    return Path(__file__).resolve().parent / "resources" / "vendor" / "XCOM"


def vendor_source_file() -> Path:
    return vendor_root() / "XCOM.f"
