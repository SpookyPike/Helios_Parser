from .attenuation import (
    AttenuationCurve,
    MaterialBudget,
    compute_multizone_transmission,
    compute_uniform_slab_transmission,
)
from .client import XCOMClient, default_client
from .models import CompoundSpec, ElementSpec, MixtureSpec, QueryResult, TransmissionResult

__all__ = [
    "AttenuationCurve",
    "MaterialBudget",
    "compute_multizone_transmission",
    "compute_uniform_slab_transmission",
    "XCOMClient",
    "default_client",
    "CompoundSpec",
    "ElementSpec",
    "MixtureSpec",
    "QueryResult",
    "TransmissionResult",
]
