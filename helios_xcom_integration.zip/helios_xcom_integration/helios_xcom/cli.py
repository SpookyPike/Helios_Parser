from __future__ import annotations

import argparse
import json

from .client import default_client
from .models import CompoundSpec, ElementSpec, MixtureSpec


def main() -> None:
    parser = argparse.ArgumentParser(description="Thin HELIOS XCOM adapter")
    sub = parser.add_subparsers(dest="cmd", required=True)

    q = sub.add_parser("query")
    q.add_argument("material")
    q.add_argument("energies", nargs="+", type=float, help="Photon energies in keV")

    args = parser.parse_args()
    client = default_client()
    material = args.material
    if ":" in material and "," in material:
        comps = []
        for chunk in material.split(","):
            name, weight = chunk.split(":", 1)
            comps.append((name.strip(), float(weight)))
        spec = MixtureSpec(comps)
    elif any(char.isdigit() for char in material):
        spec = CompoundSpec(material)
    else:
        spec = ElementSpec(symbol=material)
    result = client.query(spec, energies_kev=args.energies)
    print(json.dumps(result.to_dict(), indent=2))


if __name__ == "__main__":
    main()
