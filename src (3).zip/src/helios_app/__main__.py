from .main_app import main


if __name__ == "__main__":
    raise SystemExit(main())
