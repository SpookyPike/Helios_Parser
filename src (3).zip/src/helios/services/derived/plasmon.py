"""Quick-look XRTS / plasmon regime estimates with NRL-based unit discipline."""

from __future__ import annotations

from typing import TYPE_CHECKING
import math
from typing import Callable

import numpy as np

from helios.runtime import RunContext
from helios.services.constants.nrl import HBAR_EV_S
from helios.services.derived.common import picosecond_drive_warning
from helios.services.derived.models import DerivedPlotBundle, DerivedRunData, DerivedWarning, PlasmonResult
from helios.services.derived.selection import (
    AnalysisStateCache,
    build_analysis_mask,
    cached_time_series_payload,
    cylindrical_path_note,
    path_geometry_summary,
    profile_boundary_positions,
    profile_coordinate_values,
    resolve_weighting_mode,
    selection_cache_key,
    shared_time_series_weighted_means,
    weighted_means,
)
from helios.services.units.conversions import photon_energy_kev_to_wavelength_cm

if TYPE_CHECKING:
    from helios.services.derived.analysis import DerivedAnalysisParameters
    from helios.services.derived.models import AnalysisGeometryMetadata


def electron_debye_length_cm(te_ev: float, ne_cm3: float) -> float:
    """NRL 2023 p. 29, Fundamental Plasma Parameters, Debye length."""

    if te_ev <= 0.0 or ne_cm3 <= 0.0:
        return float("nan")
    return 7.43e2 * math.sqrt(float(te_ev) / float(ne_cm3))


def electron_plasma_frequency_rad_s(ne_cm3: float) -> float:
    """NRL 2023 p. 29, electron plasma frequency, output in rad/s."""

    if ne_cm3 <= 0.0:
        return float("nan")
    return 5.64e4 * math.sqrt(float(ne_cm3))


def coulomb_logarithm_ei(te_ev: float, ne_cm3: float, z_eff: float) -> float:
    """NRL 2023 p. 29 / p. 37 Coulomb-log quick look."""

    if te_ev <= 0.0 or ne_cm3 <= 0.0:
        return float("nan")
    lambda_d = electron_debye_length_cm(te_ev, ne_cm3)
    classical_min_cm = 1.44e-7 * max(float(z_eff), 1.0e-6) / float(te_ev)
    quantum_min_cm = 2.76e-8 / math.sqrt(float(te_ev))
    r_min = max(classical_min_cm, quantum_min_cm)
    if not math.isfinite(lambda_d) or lambda_d <= r_min or r_min <= 0.0:
        return float("nan")
    return math.log(lambda_d / r_min)


def electron_collision_rate_s(ne_cm3: float, te_ev: float, coulomb_log: float) -> float:
    """NRL 2023 p. 29, electron collision rate, output in s^-1."""

    if ne_cm3 <= 0.0 or te_ev <= 0.0 or not math.isfinite(coulomb_log) or coulomb_log <= 0.0:
        return float("nan")
    return 2.91e-6 * float(ne_cm3) * float(coulomb_log) * float(te_ev) ** (-1.5)


def ion_sound_speed_cm_s(te_ev: float, mean_charge: float, ion_mass_mu: float, gamma: float) -> float:
    """NRL 2023 p. 30, ion sound speed, output in cm/s."""

    if te_ev <= 0.0 or mean_charge <= 0.0 or ion_mass_mu <= 0.0 or gamma <= 0.0:
        return float("nan")
    return 9.79e5 * math.sqrt(float(gamma) * float(mean_charge) * float(te_ev) / float(ion_mass_mu))


def _summary_values(
    dataset: DerivedRunData,
    context: RunContext,
    parameters: "DerivedAnalysisParameters",
    geometry: "AnalysisGeometryMetadata",
    *,
    snapshot_index: int,
    weighting_mode: str,
    analysis_cache: AnalysisStateCache | None = None,
) -> tuple[dict[str, float], tuple[DerivedWarning, ...], np.ndarray]:
    mask, selection, warnings = build_analysis_mask(
        dataset,
        context,
        snapshot_index=snapshot_index,
        geometry=geometry,
        reuse_viewer_subset=parameters.reuse_viewer_subset,
        derived_region_ids=parameters.derived_region_ids,
        derived_material_ids=parameters.derived_material_ids,
        exclude_entry_region=parameters.exclude_entry_region,
        exclude_low_density=parameters.exclude_low_density,
        min_density_g_cm3=parameters.min_density_g_cm3,
        exclude_opposite_velocity=parameters.exclude_opposite_velocity,
        zone_index_lower=parameters.zone_index_lower,
        zone_index_upper=parameters.zone_index_upper,
        weighting_mode=weighting_mode,
        analysis_cache=analysis_cache,
    )
    summary_fields = np.stack(
        (
            np.asarray(dataset.temperature_e_ev[int(snapshot_index)], dtype=np.float64),
            np.asarray(dataset.temperature_i_ev[int(snapshot_index)], dtype=np.float64),
            np.asarray(dataset.electron_density_cm3[int(snapshot_index)], dtype=np.float64),
            np.asarray(dataset.mean_charge[int(snapshot_index)], dtype=np.float64),
            np.asarray(dataset.zone_atomic_weight, dtype=np.float64),
        ),
        axis=0,
    )
    te_ev, ti_ev, ne_cm3, zbar, ion_mass_mu = weighted_means(
        summary_fields,
        dataset,
        snapshot_index,
        mask,
        mode=weighting_mode,
        geometry=geometry,
        selection_key=selection_cache_key(selection),
        analysis_cache=analysis_cache,
    )
    debye_length = electron_debye_length_cm(te_ev, ne_cm3)
    omega_pe = electron_plasma_frequency_rad_s(ne_cm3)
    ln_lambda = coulomb_logarithm_ei(te_ev, ne_cm3, max(zbar, 1.0))
    collision_rate = electron_collision_rate_s(ne_cm3, te_ev, ln_lambda)
    sound_speed = ion_sound_speed_cm_s(te_ev, max(zbar, 1.0), ion_mass_mu, parameters.plasmon_adiabatic_index)
    wavelength_cm = photon_energy_kev_to_wavelength_cm(parameters.plasmon_photon_energy_kev)
    wavelength_angstrom = wavelength_cm / 1.0e-8
    scattering_wavevector = 4.0 * math.pi * math.sin(math.radians(float(parameters.plasmon_scattering_angle_deg)) / 2.0) / wavelength_cm
    k_lambda = scattering_wavevector * debye_length if math.isfinite(debye_length) else float("nan")
    collectivity = (1.0 / k_lambda) if math.isfinite(k_lambda) and k_lambda > 0.0 else float("nan")
    regime = "collective" if math.isfinite(k_lambda) and k_lambda < 1.0 else "non-collective"
    summary = {
        "te_ev": te_ev,
        "ti_ev": ti_ev,
        "ne_cm3": ne_cm3,
        "zbar": zbar,
        "ion_mass_mu": ion_mass_mu,
        "debye_length_cm": debye_length,
        "omega_pe_rad_s": omega_pe,
        "omega_pe_ev": float(HBAR_EV_S * omega_pe) if math.isfinite(omega_pe) else float("nan"),
        "collision_rate_s": collision_rate,
        "coulomb_log": ln_lambda,
        "sound_speed_cm_s": sound_speed,
        "probe_wavelength_angstrom": float(wavelength_angstrom),
        "scattering_wavevector_cm_inv": float(scattering_wavevector),
        "k_lambda": float(k_lambda),
        "collectivity": float(collectivity),
        "regime": regime,
    }
    return summary, warnings, mask


def evaluate_plasmon_regime(
    dataset: DerivedRunData,
    context: RunContext,
    *,
    snapshot_index: int,
    photon_energy_kev: float,
    scattering_angle_deg: float,
    adiabatic_index: float,
    parameters: "DerivedAnalysisParameters",
    geometry: "AnalysisGeometryMetadata",
    include_time_plots: bool = True,
    analysis_cache: AnalysisStateCache | None = None,
    progress_check: Callable[[], None] | None = None,
) -> PlasmonResult:
    """Estimate whether the selected plasma is in a collective XRTS regime."""

    del photon_energy_kev, scattering_angle_deg, adiabatic_index
    warnings: list[DerivedWarning] = []
    ps_warning = picosecond_drive_warning(
        "plasmon",
        dataset,
        "The plasmon/XRTS effective-state interpretation is less validated for ps-scale drives and may be more sensitive to transient nonequilibrium structure.",
    )
    if ps_warning is not None:
        warnings.append(ps_warning)
    cylindrical_warning = cylindrical_path_note("plasmon", dataset, geometry)
    if cylindrical_warning is not None:
        warnings.append(cylindrical_warning)
    weighting_mode = resolve_weighting_mode(parameters.weighting_mode, module_name="plasmon")
    current, selection_warnings, mask = _summary_values(
        dataset,
        context,
        parameters,
        geometry,
        snapshot_index=snapshot_index,
        weighting_mode=weighting_mode,
        analysis_cache=analysis_cache,
    )
    warnings.extend(selection_warnings)

    if not np.any(mask):
        warnings.append(DerivedWarning("plasmon", "No active zones are selected for the plasmon estimate.", severity="error"))
    elif not all(
        math.isfinite(float(current[key]))
        for key in ("te_ev", "ti_ev", "ne_cm3", "zbar", "debye_length_cm", "k_lambda")
    ):
        warnings.append(
            DerivedWarning(
                "plasmon",
                "The active weighting/filter selection did not produce a finite effective plasma state for this snapshot.",
                severity="warning",
            )
        )
    if geometry.path_length_mode in {"oblique-sec(theta)", "cylindrical-shell-unavailable-fallback-slab"} and abs(float(geometry.line_of_sight_cosine)) < 0.1:
        warnings.append(
            DerivedWarning(
                "plasmon",
                "LOS cosine is very small; sec(theta) path-length amplification may exaggerate rarefied edge contributions.",
                severity="warning",
            )
        )

    k_lambda = float(current["k_lambda"])
    collision_rate = float(current["collision_rate_s"])
    omega_pe = float(current["omega_pe_rad_s"])
    ln_lambda = float(current["coulomb_log"])
    if math.isfinite(k_lambda) and k_lambda >= 1.0:
        severity = "warning" if k_lambda >= 2.0 else "caution"
        warnings.append(DerivedWarning("plasmon", "k*lambda_D >= 1, so the selected state is in a non-collective scattering regime.", severity=severity))
    if math.isfinite(ln_lambda) and ln_lambda <= 2.0:
        warnings.append(DerivedWarning("plasmon", "Coulomb logarithm is small; weak-coupling transport estimates are becoming unreliable.", severity="warning"))
    if math.isfinite(collision_rate) and math.isfinite(omega_pe) and omega_pe > 0.0 and collision_rate / omega_pe > 0.1:
        warnings.append(DerivedWarning("plasmon", "Collision rate is a sizable fraction of the plasma frequency; strong damping is likely.", severity="caution"))

    time_plots: tuple[DerivedPlotBundle, ...] = ()
    if include_time_plots:
        time_ns = np.asarray(dataset.time_s, dtype=np.float64) * 1.0e9
        mean_series = shared_time_series_weighted_means(
            dataset,
            context,
            geometry=geometry,
            weighting_mode=weighting_mode,
            field_series=(
                ("te_ev", np.asarray(dataset.temperature_e_ev, dtype=np.float64)),
                ("ti_ev", np.asarray(dataset.temperature_i_ev, dtype=np.float64)),
                ("ne_cm3", np.asarray(dataset.electron_density_cm3, dtype=np.float64)),
                ("zbar", np.asarray(dataset.mean_charge, dtype=np.float64)),
                ("ion_mass_mu", np.asarray(dataset.zone_atomic_weight, dtype=np.float64)),
            ),
            reuse_viewer_subset=parameters.reuse_viewer_subset,
            derived_region_ids=parameters.derived_region_ids,
            derived_material_ids=parameters.derived_material_ids,
            exclude_entry_region=parameters.exclude_entry_region,
            exclude_low_density=parameters.exclude_low_density,
            min_density_g_cm3=parameters.min_density_g_cm3,
            exclude_opposite_velocity=parameters.exclude_opposite_velocity,
            zone_index_lower=parameters.zone_index_lower,
            zone_index_upper=parameters.zone_index_upper,
            analysis_cache=analysis_cache,
            progress_check=progress_check,
        )
        series_cache_key = (
            "plasmon.derived_series",
            geometry.observation_side,
            round(float(geometry.line_of_sight_angle_deg), 12),
            round(float(parameters.plasmon_photon_energy_kev), 12),
            round(float(parameters.plasmon_scattering_angle_deg), 12),
            round(float(parameters.plasmon_adiabatic_index), 12),
            weighting_mode,
            parameters.reuse_viewer_subset,
            tuple(parameters.derived_region_ids or ()),
            tuple(parameters.derived_material_ids or ()),
            bool(parameters.exclude_entry_region),
            bool(parameters.exclude_low_density),
            round(float(parameters.min_density_g_cm3), 12),
            bool(parameters.exclude_opposite_velocity),
            parameters.zone_index_lower,
            parameters.zone_index_upper,
        )

        def _build_derived_series() -> dict[str, np.ndarray]:
            te_series = np.asarray(mean_series["te_ev"], dtype=np.float64)
            ti_series = np.asarray(mean_series["ti_ev"], dtype=np.float64)
            ne_series = np.asarray(mean_series["ne_cm3"], dtype=np.float64)
            zbar_series = np.asarray(mean_series["zbar"], dtype=np.float64)
            ion_mass_series = np.asarray(mean_series["ion_mass_mu"], dtype=np.float64)
            debye_series = np.full(te_series.shape, np.nan, dtype=np.float64)
            omega_series = np.full(te_series.shape, np.nan, dtype=np.float64)
            collision_series = np.full(te_series.shape, np.nan, dtype=np.float64)
            klambda_series = np.full(te_series.shape, np.nan, dtype=np.float64)
            for time_index in range(te_series.size):
                if progress_check is not None and (time_index % 16 == 0):
                    progress_check()
                te_value = float(te_series[time_index])
                ne_value = float(ne_series[time_index])
                zbar_value = float(zbar_series[time_index])
                ion_mass_value = float(ion_mass_series[time_index])
                debye_cm = electron_debye_length_cm(te_value, ne_value)
                omega_pe = electron_plasma_frequency_rad_s(ne_value)
                ln_lambda = coulomb_logarithm_ei(te_value, ne_value, max(zbar_value, 1.0))
                collision = electron_collision_rate_s(ne_value, te_value, ln_lambda)
                _ = ion_sound_speed_cm_s(te_value, max(zbar_value, 1.0), ion_mass_value, parameters.plasmon_adiabatic_index)
                debye_series[time_index] = debye_cm * 1.0e4 if math.isfinite(debye_cm) else np.nan
                omega_series[time_index] = float(HBAR_EV_S * omega_pe) if math.isfinite(omega_pe) else np.nan
                collision_series[time_index] = float(collision)
                klambda_series[time_index] = float(current["scattering_wavevector_cm_inv"]) * debye_cm if math.isfinite(debye_cm) else np.nan
            return {
                "debye_length_um": debye_series,
                "plasma_frequency_ev": omega_series,
                "collision_rate_s": collision_series,
                "k_lambda": klambda_series,
            }

        derived_series = cached_time_series_payload(
            series_cache_key,
            analysis_cache=analysis_cache,
            builder=_build_derived_series,
        )
        te_series = np.asarray(mean_series["te_ev"], dtype=np.float64)
        ti_series = np.asarray(mean_series["ti_ev"], dtype=np.float64)
        ne_series = np.asarray(mean_series["ne_cm3"], dtype=np.float64)
        zbar_series = np.asarray(mean_series["zbar"], dtype=np.float64)
        debye_series = np.asarray(derived_series["debye_length_um"], dtype=np.float64)
        omega_series = np.asarray(derived_series["plasma_frequency_ev"], dtype=np.float64)
        collision_series = np.asarray(derived_series["collision_rate_s"], dtype=np.float64)
        klambda_series = np.asarray(derived_series["k_lambda"], dtype=np.float64)
        time_plots = (
            DerivedPlotBundle(
                key="electron_temperature",
                title="Electron temperature vs time",
                x_label="Time [ns]",
                y_label="Temperature [eV]",
                x_values=time_ns,
                y_series=(te_series,),
                curve_names=("Te",),
            ),
            DerivedPlotBundle(
                key="ion_temperature",
                title="Ion temperature vs time",
                x_label="Time [ns]",
                y_label="Temperature [eV]",
                x_values=time_ns,
                y_series=(ti_series,),
                curve_names=("Ti",),
            ),
            DerivedPlotBundle(
                key="temperatures",
                title="Electron and ion temperature vs time",
                x_label="Time [ns]",
                y_label="Temperature [eV]",
                x_values=time_ns,
                y_series=(te_series, ti_series),
                curve_names=("Te", "Ti"),
            ),
            DerivedPlotBundle(
                key="electron_density",
                title="Electron density vs time",
                x_label="Time [ns]",
                y_label="Electron density [1/cm3]",
                x_values=time_ns,
                y_series=(ne_series,),
                curve_names=("ne",),
            ),
            DerivedPlotBundle(
                key="mean_charge",
                title="Mean charge vs time",
                x_label="Time [ns]",
                y_label="Mean charge",
                x_values=time_ns,
                y_series=(zbar_series,),
                curve_names=("Zbar",),
            ),
            DerivedPlotBundle(
                key="debye_length",
                title="Debye length vs time",
                x_label="Time [ns]",
                y_label="Debye length [um]",
                x_values=time_ns,
                y_series=(debye_series,),
                curve_names=("lambda_D",),
            ),
            DerivedPlotBundle(
                key="plasma_frequency",
                title="Plasma frequency vs time",
                x_label="Time [ns]",
                y_label="hbar*omega_pe [eV]",
                x_values=time_ns,
                y_series=(omega_series,),
                curve_names=("hbar*omega_pe",),
            ),
            DerivedPlotBundle(
                key="collision_rate",
                title="Electron collision rate vs time",
                x_label="Time [ns]",
                y_label="Collision rate [1/s]",
                x_values=time_ns,
                y_series=(collision_series,),
                curve_names=("nu_e",),
            ),
            DerivedPlotBundle(
                key="k_lambda",
                title="k*lambda_D vs time",
                x_label="Time [ns]",
                y_label="k*lambda_D",
                x_values=time_ns,
                y_series=(klambda_series,),
                curve_names=("k lambda_D",),
            ),
        )

    coordinate_values, coordinate_label = profile_coordinate_values(dataset, snapshot_index, geometry.profile_coordinate_mode)
    boundary_positions = profile_boundary_positions(dataset, snapshot_index, geometry.profile_coordinate_mode)
    te_profile = np.where(mask, np.asarray(dataset.temperature_e_ev[int(snapshot_index)], dtype=np.float64), np.nan)
    ti_profile = np.where(mask, np.asarray(dataset.temperature_i_ev[int(snapshot_index)], dtype=np.float64), np.nan)
    ne_profile = np.where(mask, np.asarray(dataset.electron_density_cm3[int(snapshot_index)], dtype=np.float64) * 1.0e6, np.nan)
    zbar_profile = np.where(mask, np.asarray(dataset.mean_charge[int(snapshot_index)], dtype=np.float64), np.nan)
    local_density = np.asarray(dataset.electron_density_cm3[int(snapshot_index)], dtype=np.float64)
    local_debye = np.full(mask.shape, np.nan, dtype=np.float64)
    valid_local = mask & np.isfinite(te_profile) & np.isfinite(local_density) & (te_profile > 0.0) & (local_density > 0.0)
    local_debye[valid_local] = 7.43e2 * np.sqrt(te_profile[valid_local] / local_density[valid_local])
    local_klambda = current["scattering_wavevector_cm_inv"] * local_debye

    angle_scan = np.linspace(10.0, 140.0, 67, dtype=np.float64)
    wavelength_cm = photon_energy_kev_to_wavelength_cm(parameters.plasmon_photon_energy_kev)
    scattering_k = 4.0 * math.pi * np.sin(np.deg2rad(angle_scan) / 2.0) / wavelength_cm
    angle_scan_klambda = scattering_k * float(current["debye_length_cm"]) if np.isfinite(float(current["debye_length_cm"])) else np.full(angle_scan.shape, np.nan, dtype=np.float64)

    geometry_summary = (
        f"{geometry.observation_side} side | LOS cos={geometry.line_of_sight_cosine:.3f} | "
        f"profile={geometry.profile_coordinate_mode} | {path_geometry_summary(dataset, geometry)}"
    )

    return PlasmonResult(
        snapshot_index=int(snapshot_index),
        weighting_mode=weighting_mode,
        geometry_summary=geometry_summary,
        electron_density_cm3=float(current["ne_cm3"]),
        electron_temperature_ev=float(current["te_ev"]),
        ion_temperature_ev=float(current["ti_ev"]),
        mean_charge=float(current["zbar"]),
        ion_mass_mu=float(current["ion_mass_mu"]),
        debye_length_cm=float(current["debye_length_cm"]),
        plasma_frequency_rad_s=float(current["omega_pe_rad_s"]),
        plasma_frequency_ev=float(current["omega_pe_ev"]),
        electron_collision_rate_s=float(current["collision_rate_s"]),
        coulomb_logarithm=float(current["coulomb_log"]),
        ion_sound_speed_cm_s=float(current["sound_speed_cm_s"]),
        probe_wavelength_angstrom=float(current["probe_wavelength_angstrom"]),
        scattering_wavevector_cm_inv=float(current["scattering_wavevector_cm_inv"]),
        k_lambda_debye=float(current["k_lambda"]),
        collectivity_parameter=float(current["collectivity"]),
        regime_label=str(current["regime"]),
        time_plots=time_plots,
        profile_plots=(
            DerivedPlotBundle(
                key="electron_temperature_profile",
                title="Electron temperature profile",
                x_label=coordinate_label,
                y_label="Temperature [eV]",
                x_values=np.asarray(coordinate_values, dtype=np.float64),
                y_series=(te_profile,),
                curve_names=("Te",),
                boundary_positions=boundary_positions,
            ),
            DerivedPlotBundle(
                key="ion_temperature_profile",
                title="Ion temperature profile",
                x_label=coordinate_label,
                y_label="Temperature [eV]",
                x_values=np.asarray(coordinate_values, dtype=np.float64),
                y_series=(ti_profile,),
                curve_names=("Ti",),
                boundary_positions=boundary_positions,
            ),
            DerivedPlotBundle(
                key="temperature_profile",
                title="Electron and ion temperature profile",
                x_label=coordinate_label,
                y_label="Temperature [eV]",
                x_values=np.asarray(coordinate_values, dtype=np.float64),
                y_series=(te_profile, ti_profile),
                curve_names=("Te", "Ti"),
                boundary_positions=boundary_positions,
            ),
            DerivedPlotBundle(
                key="electron_density_profile",
                title="Electron density profile",
                x_label=coordinate_label,
                y_label="Electron density [1/m3]",
                x_values=np.asarray(coordinate_values, dtype=np.float64),
                y_series=(ne_profile,),
                curve_names=("ne",),
                boundary_positions=boundary_positions,
            ),
            DerivedPlotBundle(
                key="mean_charge_profile",
                title="Mean charge profile",
                x_label=coordinate_label,
                y_label="Mean charge",
                x_values=np.asarray(coordinate_values, dtype=np.float64),
                y_series=(zbar_profile,),
                curve_names=("Zbar",),
                boundary_positions=boundary_positions,
            ),
            DerivedPlotBundle(
                key="local_k_lambda_profile",
                title="Local k*lambda_D profile",
                x_label=coordinate_label,
                y_label="k*lambda_D",
                x_values=np.asarray(coordinate_values, dtype=np.float64),
                y_series=(np.asarray(local_klambda, dtype=np.float64),),
                curve_names=("k lambda_D",),
                boundary_positions=boundary_positions,
            ),
            DerivedPlotBundle(
                key="angle_scan",
                title="k*lambda_D scan vs scattering angle",
                x_label="Scattering angle [deg]",
                y_label="k*lambda_D",
                x_values=np.asarray(angle_scan, dtype=np.float64),
                y_series=(np.asarray(angle_scan_klambda, dtype=np.float64),),
                curve_names=("Current snapshot",),
            ),
        ),
        warnings=tuple(warnings),
    )
