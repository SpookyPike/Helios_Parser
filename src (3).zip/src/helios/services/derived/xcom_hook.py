"""Optional cold-attenuation backend seam for future XCOM integration.

Phase 4.1 keeps Thomson transmission as the default quick-look baseline. This
module defines the narrow request/response boundary that a future neutral/cold
attenuation backend can implement without forcing a redesign of Derived mode or
the transmission UI.

The intent is to pass already-selected HELIOS snapshot data:

- per-zone material identifiers / labels
- density [g/cm3]
- LOS path length [cm]
- photon energies [keV]

and receive back a transmission curve. The backend remains optional and lazy:
the app must still run without XCOM or any other external attenuation package.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import sys
import threading
import time
from typing import Any, Protocol

import numpy as np

from helios.platform.archive_utils import extract_archive
from helios.runtime import RunContext
from helios.services.derived.models import DerivedRunData
from helios.services.derived.selection import build_analysis_mask, path_length_cm


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[4]


def _wrapper_archive_path() -> Path:
    return _repo_root() / "helios_xcom_integration.zip"


def _source_archive_path() -> Path:
    return _repo_root() / "XCOM.tar.gz"


def _app_data_root() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "HeliosViewer" / "HELIOS Parse View" / "derived" / "xcom"


def _archive_fingerprint(path: Path) -> str:
    stats = path.stat()
    return f"{path.name}:{int(stats.st_size)}:{int(stats.st_mtime_ns)}"


def _stamp_path(root: Path) -> Path:
    return root / ".archive_stamp.json"


def _ensure_wrapper_root() -> Path:
    archive = _wrapper_archive_path()
    if not archive.exists():
        raise FileNotFoundError(f"Missing optional XCOM wrapper archive: {archive}")
    destination = _app_data_root() / "wrapper"
    marker = _stamp_path(destination)
    expected = {"fingerprint": _archive_fingerprint(archive)}
    package_root = destination / "helios_xcom_integration"
    if marker.exists() and package_root.exists():
        try:
            current = json.loads(marker.read_text(encoding="utf-8"))
        except Exception:
            current = {}
        if current == expected:
            return destination
    if destination.exists():
        shutil.rmtree(destination, ignore_errors=True)
    destination.mkdir(parents=True, exist_ok=True)
    extract_archive(archive, destination)
    marker.write_text(json.dumps(expected, indent=2), encoding="utf-8")
    return destination


def _material_label_from_value(value: object) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    candidate = Path(text).stem.strip() if ("\\" in text or "/" in text or "." in Path(text).name) else text
    if not candidate:
        return None
    if not any(character.isalpha() for character in candidate):
        return None
    lowered = candidate.lower()
    if lowered in {"eosopa", "sesame", "material", "opacity"}:
        return None
    return candidate


def _material_labels_by_id(dataset: DerivedRunData) -> dict[int, str]:
    materials = dataset.materials if isinstance(dataset.materials, dict) else {}
    labels: dict[int, str] = {}
    if "index" not in materials:
        return labels
    material_ids = np.asarray(materials["index"], dtype=np.int32)
    preferred_keys = ("label", "opacity_file_path", "eos_file_path")
    for key in preferred_keys:
        if key not in materials:
            continue
        for material_id, raw_value in zip(material_ids.tolist(), materials[key], strict=False):
            label = _material_label_from_value(raw_value)
            if label is not None:
                labels[int(abs(material_id))] = label
    return labels


def _material_resolution_summary(
    request: "ColdAttenuationRequest",
) -> tuple[dict[str, float], tuple[str, ...], tuple[str, ...]]:
    grouped: dict[str, float] = {}
    unresolved: list[str] = []
    for zone in request.zones:
        label = _material_label_from_value(zone.material_label)
        if label is None:
            unresolved_label = f"material {int(zone.material_id)}"
            if unresolved_label not in unresolved:
                unresolved.append(unresolved_label)
            continue
        grouped[label] = float(grouped.get(label, 0.0) + float(zone.density_g_cm3) * float(zone.path_length_cm))
    resolved = tuple(sorted(grouped))
    return grouped, resolved, tuple(unresolved)


def _cache_file_path() -> Path:
    return _app_data_root() / "multizone_request_cache.json"


_CACHE_LOCK = threading.Lock()
_XCOM_MODULE_LOCK = threading.Lock()
_XCOM_MODULE: object | None = None
_XCOM_BACKEND: "HeliosXcomBackend | None" = None


@dataclass(frozen=True, slots=True)
class ColdAttenuationZone:
    """Single-zone attenuation input for an optional cold backend."""

    zone_index: int
    region_id: int
    material_id: int
    material_label: str | None
    density_g_cm3: float
    path_length_cm: float


@dataclass(frozen=True, slots=True)
class ColdAttenuationRequest:
    """Structured snapshot request that a future XCOM-like backend can consume."""

    snapshot_index: int
    observation_side: str
    line_of_sight_cosine: float
    photon_energies_kev: tuple[float, ...]
    zones: tuple[ColdAttenuationZone, ...]


@dataclass(frozen=True, slots=True)
class ColdAttenuationResult:
    """Backend response for a future cold-baseline transmission service."""

    energies_kev: np.ndarray
    transmission: np.ndarray
    metadata: dict[str, object]


@dataclass(frozen=True, slots=True)
class ColdAttenuationBackendStatus:
    available: bool
    status: str
    message: str
    backend_name: str | None = None
    backend_fingerprint: str | None = None


class OptionalColdAttenuationBackend(Protocol):
    """Protocol implemented by optional attenuation backends such as XCOM."""

    def compute_transmission(self, request: ColdAttenuationRequest) -> ColdAttenuationResult:
        """Return transmission for the supplied snapshot request."""


class PersistentColdAttenuationCache:
    """Small persisted LRU cache for successful multizone attenuation requests."""

    def __init__(self, path: Path | None = None, *, max_entries: int = 10) -> None:
        self.path = _cache_file_path() if path is None else Path(path)
        self.max_entries = max(1, int(max_entries))
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict[str, object]:
        if not self.path.exists():
            return {"version": 1, "entries": []}
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {"version": 1, "entries": []}
        if not isinstance(payload, dict):
            return {"version": 1, "entries": []}
        entries = payload.get("entries", [])
        if not isinstance(entries, list):
            entries = []
        return {"version": 1, "entries": entries}

    def _save(self, payload: dict[str, object]) -> None:
        self.path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    def get(self, cache_key: str) -> dict[str, object] | None:
        with _CACHE_LOCK:
            payload = self._load()
            entries = [entry for entry in payload.get("entries", []) if isinstance(entry, dict)]
            now = time.time()
            hit: dict[str, object] | None = None
            for entry in entries:
                if str(entry.get("cache_key", "")) != str(cache_key):
                    continue
                entry["last_used_at"] = now
                hit = dict(entry)
                break
            if hit is None:
                return None
            entries.sort(key=lambda item: float(item.get("last_used_at", 0.0)), reverse=True)
            payload["entries"] = entries[: self.max_entries]
            self._save(payload)
            return hit

    def put(self, cache_key: str, *, request_payload: dict[str, object], result_payload: dict[str, object]) -> None:
        with _CACHE_LOCK:
            payload = self._load()
            entries = [entry for entry in payload.get("entries", []) if isinstance(entry, dict)]
            now = time.time()
            entries = [entry for entry in entries if str(entry.get("cache_key", "")) != str(cache_key)]
            entries.append(
                {
                    "cache_key": str(cache_key),
                    "created_at": now,
                    "last_used_at": now,
                    "request": dict(request_payload),
                    "result": dict(result_payload),
                }
            )
            entries.sort(key=lambda item: float(item.get("last_used_at", 0.0)), reverse=True)
            payload["entries"] = entries[: self.max_entries]
            self._save(payload)


def persistent_cold_attenuation_cache() -> PersistentColdAttenuationCache:
    return PersistentColdAttenuationCache()


def clear_persistent_cold_attenuation_cache(path: Path | None = None) -> None:
    cache = PersistentColdAttenuationCache(path=path) if path is not None else persistent_cold_attenuation_cache()
    if cache.path.exists():
        cache.path.unlink()


def cold_attenuation_cache_key(
    request: ColdAttenuationRequest,
    *,
    backend_fingerprint: str,
    attenuation_mode: str = "total_with_coherent",
) -> tuple[str, dict[str, object]]:
    grouped, _resolved, unresolved = _material_resolution_summary(request)
    payload = {
        "schema_version": 1,
        "backend_fingerprint": str(backend_fingerprint),
        "attenuation_mode": str(attenuation_mode),
        "energies_kev": [round(float(value), 9) for value in request.photon_energies_kev],
        "materials": [
            {"label": label, "areal_density_g_cm2": round(float(grouped[label]), 12)}
            for label in sorted(grouped)
        ],
        "unresolved_materials": list(unresolved),
    }
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest(), payload


def _load_helios_xcom_module() -> object:
    global _XCOM_MODULE
    if _XCOM_MODULE is not None:
        return _XCOM_MODULE
    with _XCOM_MODULE_LOCK:
        if _XCOM_MODULE is not None:
            return _XCOM_MODULE
        wrapper_root = _ensure_wrapper_root() / "helios_xcom_integration"
        if str(wrapper_root) not in sys.path:
            sys.path.insert(0, str(wrapper_root))
        _XCOM_MODULE = importlib.import_module("helios_xcom")
        return _XCOM_MODULE


def describe_optional_cold_backend() -> ColdAttenuationBackendStatus:
    wrapper_archive = _wrapper_archive_path()
    if wrapper_archive.exists():
        return ColdAttenuationBackendStatus(
            available=True,
            status="available",
            message="XCOM wrapper archive detected. Runtime build/execution is checked on explicit refine requests.",
            backend_name="XCOM",
            backend_fingerprint=_archive_fingerprint(wrapper_archive),
        )
    source_archive = _source_archive_path()
    if source_archive.exists():
        return ColdAttenuationBackendStatus(
            available=False,
            status="source_only",
            message="Vendor XCOM source bundle is present, but the Python wrapper archive is not available.",
            backend_name="XCOM",
            backend_fingerprint=_archive_fingerprint(source_archive),
        )
    return ColdAttenuationBackendStatus(
        available=False,
        status="unavailable",
        message="Optional XCOM backend is not installed.",
        backend_name="XCOM",
    )


class HeliosXcomBackend:
    """Optional cold-attenuation backend implemented through helios_xcom."""

    backend_name = "XCOM"

    def __init__(self) -> None:
        module = _load_helios_xcom_module()
        self._module = module
        self._client = module.default_client()

    @property
    def backend_fingerprint(self) -> str:
        return str(self._client.backend.backend_fingerprint)

    def compute_transmission(self, request: ColdAttenuationRequest) -> ColdAttenuationResult:
        material_specs: list[str] = []
        density_values: list[float] = []
        path_values: list[float] = []
        for zone in request.zones:
            label = _material_label_from_value(zone.material_label)
            if label is None:
                raise ValueError(f"XCOM refinement requires a resolvable material label for material {int(zone.material_id)}.")
            material_specs.append(label)
            density_values.append(float(zone.density_g_cm3))
            path_values.append(float(zone.path_length_cm))
        curve = self._module.compute_multizone_transmission(
            self._client,
            material_specs=material_specs,
            density_g_cm3=density_values,
            path_length_cm=path_values,
            energies_kev=request.photon_energies_kev,
        )
        grouped_budgets: dict[str, dict[str, object]] = {}
        for budget in getattr(curve, "per_material", ()):
            label = str(getattr(budget, "label", "") or "").strip() or "unknown"
            existing = grouped_budgets.get(
                label,
                {
                    "label": label,
                    "areal_density_g_cm2": 0.0,
                    "optical_depth": [0.0 for _ in getattr(budget, "optical_depth", ())],
                },
            )
            existing["areal_density_g_cm2"] = float(existing["areal_density_g_cm2"]) + float(getattr(budget, "areal_density_g_cm2", 0.0))
            for index, value in enumerate(getattr(budget, "optical_depth", ())):
                existing["optical_depth"][index] = float(existing["optical_depth"][index]) + float(value)
            grouped_budgets[label] = existing
        metadata = {
            "backend_name": self.backend_name,
            "backend_fingerprint": self.backend_fingerprint,
            "attenuation_mode": str(getattr(curve, "attenuation_mode", "total_with_coherent")),
            "optical_depth": [float(value) for value in getattr(curve, "optical_depth", ())],
            "material_budgets": [
                {
                    "label": label,
                    "areal_density_g_cm2": float(payload["areal_density_g_cm2"]),
                    "optical_depth": [float(value) for value in payload["optical_depth"]],
                }
                for label, payload in sorted(grouped_budgets.items())
            ],
        }
        return ColdAttenuationResult(
            energies_kev=np.asarray(getattr(curve, "energies_kev", ()), dtype=np.float64),
            transmission=np.asarray(getattr(curve, "transmission", ()), dtype=np.float64),
            metadata=metadata,
        )


def load_optional_cold_backend() -> OptionalColdAttenuationBackend | None:
    global _XCOM_BACKEND
    status = describe_optional_cold_backend()
    if not status.available:
        return None
    if _XCOM_BACKEND is None:
        try:
            _XCOM_BACKEND = HeliosXcomBackend()
        except Exception:
            return None
    return _XCOM_BACKEND


def build_cold_attenuation_request(
    dataset: DerivedRunData,
    context: RunContext,
    *,
    snapshot_index: int,
    parameters,
    geometry,
    photon_energies_kev: tuple[float, ...],
) -> ColdAttenuationRequest:
    """Build the future optional-backend request from the active Derived context.

    This does not call any external backend. It only packages the current HELIOS
    snapshot subset into a stable request object for later attachment to an
    optional XCOM-like service.
    """

    mask, _, _ = build_analysis_mask(
        dataset,
        context,
        snapshot_index=snapshot_index,
        geometry=geometry,
        reuse_viewer_subset=parameters.reuse_viewer_subset,
        derived_region_ids=parameters.derived_region_ids,
        derived_material_ids=parameters.derived_material_ids,
        exclude_entry_region=parameters.exclude_entry_region,
        exclude_low_density=parameters.exclude_low_density,
        min_density_g_cm3=parameters.min_density_g_cm3,
        exclude_opposite_velocity=parameters.exclude_opposite_velocity,
        zone_index_lower=parameters.zone_index_lower,
        zone_index_upper=parameters.zone_index_upper,
        weighting_mode="path_integrated",
    )

    density = np.asarray(dataset.density_g_cm3[int(snapshot_index)], dtype=np.float64)
    path = np.asarray(path_length_cm(dataset, snapshot_index, geometry), dtype=np.float64)
    material_labels_by_id = _material_labels_by_id(dataset)

    zones: list[ColdAttenuationZone] = []
    for zone_index in np.flatnonzero(mask):
        material_id = int(abs(dataset.zone_material_index[zone_index]))
        zones.append(
            ColdAttenuationZone(
                zone_index=int(zone_index + 1),
                region_id=int(dataset.zone_region_id[zone_index]),
                material_id=material_id,
                material_label=material_labels_by_id.get(material_id),
                density_g_cm3=float(density[zone_index]),
                path_length_cm=float(path[zone_index]),
            )
        )

    return ColdAttenuationRequest(
        snapshot_index=int(snapshot_index),
        observation_side=str(geometry.observation_side),
        line_of_sight_cosine=float(geometry.line_of_sight_cosine),
        photon_energies_kev=tuple(float(value) for value in photon_energies_kev),
        zones=tuple(zones),
    )
